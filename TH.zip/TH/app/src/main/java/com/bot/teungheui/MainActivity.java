package com.bot.teungheui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends AppCompatActivity {

    private WebView myWebView;
    private int retryCount = 0;
    private static final int MAX_RETRY = 30;
    private static final String SERVER_URL = "http://127.0.0.1:8080";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. XIN QUYỀN BỘ NHỚ
        requestStoragePermission();

        // 2. XIN QUYỀN THÔNG BÁO (Android 13+) + kiểm tra đã bật chưa
        requestNotificationPermission();

        // 3. KHỞI ĐỘNG PYTHON
        try {
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(this));
            }
            Python.getInstance().getModule("app").callAttr("run_server");
        } catch (Exception e) {
            Toast.makeText(this, "Lỗi khởi động Python: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }

        // 4. WEBVIEW
        setContentView(R.layout.activity_main);
        myWebView = findViewById(R.id.webview);

        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webSettings.setDatabaseEnabled(true);

        // CẦU NỐI JS → JAVA
        myWebView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void openBatterySettings() {
                Intent intent = new Intent();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    intent.setAction(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                } else {
                    intent.setAction(Settings.ACTION_SETTINGS);
                }
                startActivity(intent);
            }

            @JavascriptInterface
            public void openNotificationSettings() {
                Intent intent = new Intent();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    intent.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                } else {
                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                }
                startActivity(intent);
            }

            @JavascriptInterface
            public boolean isNotificationEnabled() {
                return NotificationManagerCompat.from(MainActivity.this).areNotificationsEnabled();
            }

            @JavascriptInterface
            public void showNotification(String title, String content) {
                try {
                    android.app.NotificationManager nm =
                        (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    String channelId = "snow_panel_alerts";

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        android.app.NotificationChannel ch = new android.app.NotificationChannel(
                            channelId, "Cảnh báo Snow Panel",
                            android.app.NotificationManager.IMPORTANCE_HIGH);
                        ch.enableVibration(true);
                        ch.setVibrationPattern(new long[]{0, 300, 200, 300});
                        ch.enableLights(true);
                        ch.setLightColor(0xFF4F46E5);
                        ch.setShowBadge(true);
                        nm.createNotificationChannel(ch);
                    }

                    Intent intent = new Intent(MainActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                        ? android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE
                        : android.app.PendingIntent.FLAG_UPDATE_CURRENT;
                    android.app.PendingIntent pi = android.app.PendingIntent.getActivity(
                        MainActivity.this, (int) System.currentTimeMillis(), intent, flags);

                    androidx.core.app.NotificationCompat.Builder builder =
                        new androidx.core.app.NotificationCompat.Builder(MainActivity.this, channelId)
                            .setSmallIcon(android.R.drawable.ic_dialog_alert)
                            .setContentTitle(title)
                            .setContentText(content)
                            .setStyle(new androidx.core.app.NotificationCompat.BigTextStyle().bigText(content))
                            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                            .setCategory(androidx.core.app.NotificationCompat.CATEGORY_ALARM)
                            .setAutoCancel(true)
                            .setContentIntent(pi)
                            .setDefaults(androidx.core.app.NotificationCompat.DEFAULT_ALL);

                    nm.notify((int) System.currentTimeMillis(), builder.build());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, "Android");

        // WEBVIEW CLIENT — có retry khi server chưa lên
        myWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    if (request.getUrl().toString().startsWith(SERVER_URL)) {
                        scheduleRetry(view);
                    }
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                if (failingUrl != null && failingUrl.startsWith(SERVER_URL)) {
                    scheduleRetry(view);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                retryCount = 0;
            }
        });

        // CẤP QUYỀN MIC/CAMERA CHO WEBVIEW
        myWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        // LOAD URL SAU 2 GIÂY
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            myWebView.loadUrl(SERVER_URL);
        }, 2000);
    }

    private void scheduleRetry(final WebView view) {
        if (retryCount >= MAX_RETRY) {
            Toast.makeText(MainActivity.this,
                "Không kết nối được server Python (port 8080). Kiểm tra app.py!",
                Toast.LENGTH_LONG).show();
            return;
        }
        retryCount++;
        new Handler(Looper.getMainLooper()).postDelayed(() -> view.loadUrl(SERVER_URL), 1000);
    }

    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    intent.addCategory("android.intent.category.DEFAULT");
                    intent.setData(Uri.parse(String.format("package:%s", getApplicationContext().getPackageName())));
                    startActivityForResult(intent, 2296);
                } catch (Exception e) {
                    Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    startActivityForResult(intent, 2296);
                }
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
            }
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!NotificationManagerCompat.from(this).areNotificationsEnabled()) {
                Toast.makeText(this,
                    "⚠️ Thông báo đang TẮT. Vào Cài đặt → Ứng dụng → Snow Panel → Thông báo để bật.",
                    Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 2) {
            if (grantResults.length > 0 && grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this,
                    "⚠️ Bạn đã từ chối quyền thông báo. App sẽ không báo được khi ACC die.\n" +
                    "Vào Cài đặt → Ứng dụng → Snow Panel → Thông báo để bật lại.",
                    Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (myWebView != null && myWebView.canGoBack()) {
            myWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}