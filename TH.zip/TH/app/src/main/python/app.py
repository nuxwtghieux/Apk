import random
import string
import json
import time
import uuid
import base64
import io
import struct
import re
import os
import threading
import requests
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from Crypto.Cipher import AES, PKCS1_v1_5
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__, static_folder='.')
CORS(app)

DB_FILE = os.path.join(os.path.dirname(__file__), 'accounts.json')
running_bots = {}
bot_logs = {}

TIMEOUT = 15
MISTRAL_API_KEY = "mstrl_N4uIpAyBTp3TNxDOPdLAfp64R1Sl9UVx_3DK7oj"
MISTRAL_API_URL = "https://api.mistral.ai/v1/chat/completions"
MODEL_AI = "mistral-tiny"

# ==========================================================
# HÀM XỬ LÝ PROXY & LẤY TÊN
# ==========================================================
def parse_proxy(proxy_str):
    if not proxy_str or proxy_str.strip() == "": return None
    p = proxy_str.strip()
    if "://" in p: return {"http": p, "https": p}
    parts = p.split(":")
    if len(parts) == 4:
        return {"http": f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}", "https": f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"}
    elif len(parts) == 2:
        return {"http": f"http://{parts[0]}:{parts[1]}", "https": f"http://{parts[0]}:{parts[1]}"}
    return {"http": f"http://{p}", "https": f"http://{p}"}

def get_fb_name(token, proxies=None):
    try:
        url = "https://graph.facebook.com/v18.0/me"
        params = {"fields": "id,name", "access_token": token}
        res = requests.get(url, params=params, proxies=proxies, timeout=15, verify=False)
        if res.status_code == 200:
            return res.json().get("name", "Không lấy được tên")
        return "Token lỗi"
    except: return "Lỗi mạng"

# ==========================================================
# CODE GỐC CỦA BẠN (ĐÃ CẬP NHẬT ĐỒNG BỘ THIẾT BỊ)
# ==========================================================
class facebook_password_encryptor:
    @staticmethod
    def get_public_key(proxies=None):
        try:
            url = 'https://b-graph.facebook.com/pwd_key_fetch'
            params = {'version': '2', 'flow': 'CONTROLLER_INITIALIZATION', 'method': 'GET', 'fb_api_req_friendly_name': 'pwdKeyFetch', 'fb_api_caller_class': 'com.facebook.auth.login.AuthOperations', 'access_token': '438142079694454|fc0a7caa49b192f64f6f5a6d9643bb28'}
            res = requests.post(url, params=params, proxies=proxies, timeout=TIMEOUT, verify=False).json()
            return res.get('public_key'), str(res.get('key_id', '25'))
        except: return None, "25"

    @staticmethod
    def encrypt(password, public_key=None, key_id="25", proxies=None):
        if public_key is None: public_key, key_id = facebook_password_encryptor.get_public_key(proxies)
        try:
            rand_key = get_random_bytes(32)
            iv = get_random_bytes(12)
            pubkey = RSA.import_key(public_key)
            cipher_rsa = PKCS1_v1_5.new(pubkey)
            encrypted_rand_key = cipher_rsa.encrypt(rand_key)
            cipher_aes = AES.new(rand_key, AES.MODE_GCM, nonce=iv)
            current_time = int(time.time())
            cipher_aes.update(str(current_time).encode("utf-8"))
            encrypted_passwd, auth_tag = cipher_aes.encrypt_and_digest(password.encode("utf-8"))
            buf = io.BytesIO()
            buf.write(bytes([1, int(key_id)]))
            buf.write(iv)
            buf.write(struct.pack("<h", len(encrypted_rand_key)))
            buf.write(encrypted_rand_key)
            buf.write(auth_tag)
            buf.write(encrypted_passwd)
            return f"#PWD_FB4A:2:{current_time}:{base64.b64encode(buf.getvalue()).decode('utf-8')}"
        except: return password

class facebook_login:
    API_URL = "https://b-graph.facebook.com/auth/login"
    ACCESS_TOKEN = "350685531728|62f8ce9f74b12f84c123cc23437a4a32"
    API_KEY = "882a8490361da98702bf97a021ddc14d"
    SIG = "214049b9f17c38bd767de53752b53946"
    BASE_HEADERS = {"content-type": "application/x-www-form-urlencoded", "x-fb-net-hni": "45201", "zero-rated": "0", "x-fb-sim-hni": "45201", "x-fb-connection-quality": "EXCELLENT", "x-fb-friendly-name": "authenticate", "x-fb-connection-bandwidth": "78032897", "x-tigon-is-retry": "False", "authorization": "OAuth null", "x-fb-connection-type": "WIFI", "x-fb-device-group": "3342", "priority": "u=3,i", "x-fb-http-engine": "Liger", "x-fb-client-ip": "True", "x-fb-server-cluster": "True"}

    def __init__(self, uid_phone_mail, password, twofactor_code=None, proxies=None, device_info=None):
        self.uid_phone_mail = uid_phone_mail
        self.twofactor_code = twofactor_code
        self.proxies = proxies
        
        # SỬA LỖI 1 & 2: Tái sử dụng toàn bộ thông tin thiết bị nếu đã có
        if device_info:
            self.machine_id = device_info.get('machine_id')
            self.device_id = device_info.get('device_id')
            self.adid = device_info.get('adid')
            self.secure_family_device_id = device_info.get('secure_family_device_id')
            self.user_agent = device_info.get('user_agent')
            self.jazoest = device_info.get('jazoest')
            self.sim_serial = device_info.get('sim_serial')
        else:
            # Nếu là lần đầu, tạo mới hoàn toàn
            self.machine_id = ''.join(random.choices(string.ascii_letters + string.digits, k=24))
            self.device_id = str(uuid.uuid4())
            self.adid = str(uuid.uuid4())
            self.secure_family_device_id = str(uuid.uuid4())
            self.user_agent = "Dalvik/2.1.0 (Linux; U; Android 9; 23113RKC6C Build/PQ3A.190705.08211809) [FBAN/FB4A;FBAV/417.0.0.33.65;FBPN/com.facebook.katana;FBLC/vi_VN;FBBV/480086274;FBCR/MobiFone;FBMF/Redmi;FBBD/Redmi;FBDV/23113RKC6C;FBSV/9;FBCA/x86:armeabi-v7a;FBDM/{density=1.5,width=1280,height=720};FB_FW/1;FBRV/0;]"
            self.jazoest = ''.join(random.choices(string.digits, k=5))
            self.sim_serial = ''.join(random.choices(string.digits, k=20))

        self.password = password if password.startswith("#PWD_FB4A") else facebook_password_encryptor.encrypt(password, proxies=proxies)
        self.session = requests.Session()
        if self.proxies: self.session.proxies.update(self.proxies)
        self.headers = self._build_headers()
        self.data = self._build_data()

    def _build_headers(self):
        headers = self.BASE_HEADERS.copy()
        headers.update({"x-fb-request-analytics-tags": '{"network_tags":{"product":"350685531728","retry_attempt":"0"},"application_tags":"unknown"}', "user-agent": self.user_agent})
        return headers

    def _build_data(self):
        return {"format": "json", "email": self.uid_phone_mail, "password": self.password, "credentials_type": "password", "generate_session_cookies": "1", "api_key": self.API_KEY, "access_token": self.ACCESS_TOKEN, "adid": self.adid, "device_id": self.device_id, "generate_analytics_claim": "1", "community_id": "", "linked_guest_account_userid": "", "cpl": "true", "try_num": "1", "family_device_id": self.device_id, "secure_family_device_id": self.secure_family_device_id, "sim_serials": f'["{self.sim_serial}"]', "openid_flow": "android_login", "openid_provider": "google", "openid_tokens": "[]", "account_switcher_uids": f'["{self.uid_phone_mail}"]', "fb4a_shared_phone_cpl_experiment": "fb4a_shared_phone_nonce_cpl_at_risk_v3", "fb4a_shared_phone_cpl_group": "enable_v3_at_risk", "enroll_misauth": "false", "error_detail_type": "button_with_disabled", "source": "login", "machine_id": self.machine_id, "jazoest": self.jazoest, "meta_inf_fbmeta": "V2_UNTAGGED", "advertiser_id": self.adid, "encrypted_msisdn": "", "currently_logged_in_userid": "0", "fb_api_req_friendly_name": "authenticate", "fb_api_caller_class": "Fb4aAuthHandler", "sig": self.SIG}

    def _parse_success(self, res_json):
        c_dict, c_str = {}, ""
        if 'session_cookies' in res_json:
            for c in res_json['session_cookies']:
                c_dict[c['name']] = c['value']
                c_str += f"{c['name']}={c['value']}; "
        return {
            'success': True, 
            'access_token': res_json['access_token'], 
            'cookies': {'dict': c_dict, 'string': c_str.rstrip('; ')},
            'device_info': { # Lưu lại toàn bộ thông tin thiết bị
                'machine_id': self.machine_id,
                'device_id': self.device_id,
                'adid': self.adid,
                'secure_family_device_id': self.secure_family_device_id,
                'user_agent': self.user_agent,
                'jazoest': self.jazoest,
                'sim_serial': self.sim_serial
            }
        }

    def _handle_2fa(self, error_data):
        if not self.twofactor_code: return {'success': False, 'error': 'Yêu cầu 2FA nhưng chưa nhập mã.'}
        data_2fa = self._build_data()
        data_2fa.update({"credentials_type": "two_factor", "twofactor_code": self.twofactor_code, "first_factor": error_data.get('login_first_factor'), "userid": error_data.get('uid')})
        try:
            res = self.session.post(self.API_URL, headers=self.headers, data=data_2fa, proxies=self.proxies, verify=False).json()
            if 'access_token' in res: return self._parse_success(res)
            return {'success': False, 'error': res.get('error', {}).get('message', 'Mã 2FA sai')}
        except Exception as e: return {'success': False, 'error': f'Lỗi 2FA: {e}'}

    def login(self):
        try:
            # SỬA LỖI 3: Kiểm tra proxy trước khi login, nếu proxy die thì báo rõ
            if self.proxies:
                try:
                    requests.get("https://api.ipify.org", proxies=self.proxies, timeout=10, verify=False)
                except:
                    return {'success': False, 'error': 'Proxy không hoạt động (Lỗi kết nối)'}

            response = self.session.post(self.API_URL, headers=self.headers, data=self.data, proxies=self.proxies, verify=False)
            response_json = response.json()
            if 'access_token' in response_json:
                return self._parse_success(response_json)
            if 'error' in response_json:
                err_data = response_json['error'].get('error_data', {})
                if 'login_first_factor' in err_data and 'uid' in err_data: return self._handle_2fa(err_data)
                return {'success': False, 'error': response_json['error'].get('message', 'Lỗi không xác định')}
            return {'success': False, 'error': 'Sai định dạng phản hồi'}
        except Exception: 
            return {'success': False, 'error': 'Lỗi kết nối Python/Proxy'}

# ==========================================================
# CÁC HÀM PHỤ TRỢ & API (Giữ nguyên)
# ==========================================================
UA_PC = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
HEADERS_BASE = {"User-Agent": UA_PC, "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8", "Accept-Language": "en-US,en;q=0.9"}

def tao_phien(c_dict, proxies=None):
    s = requests.Session()
    s.headers.update(HEADERS_BASE)
    for k, v in c_dict.items(): s.cookies.set(k, v, domain=".facebook.com")
    if proxies: s.proxies.update(proxies)
    return s

def lay_metadata(s, proxies=None):
    meta = {"fb_dtsg": None, "lsd": None}
    try:
        r = s.get("https://www.facebook.com/", timeout=TIMEOUT, proxies=proxies, verify=False)
        m = re.search(r'"DTSGInitialData":\{"token":"(.*?)"', r.text) or re.search(r'\["DTSGInitialData",\[\],\{"token":"(.*?)"\}', r.text)
        if m: meta["fb_dtsg"] = m.group(1)
        m = re.search(r'"LSD":\{"token":"(.*?)"', r.text) or re.search(r'\["LSD",\[\],\{"token":"(.*?)"\}', r.text)
        if m: meta["lsd"] = m.group(1)
    except: pass
    if not meta["fb_dtsg"]:
        try:
            r = s.get("https://business.facebook.com/", timeout=TIMEOUT, proxies=proxies, verify=False)
            m = re.search(r'name="fb_dtsg" value="([^"]+)"', r.text) or re.search(r'"DTSGInitialData",\[\],\{"token":"([^"]+)"', r.text)
            if m: meta["fb_dtsg"] = m.group(1)
        except: pass
    return meta

class facebook_ai:
    def __init__(self, api_key):
        self.api_key = api_key
        self.model = MODEL_AI

    def _goi_ai(self, prompt, proxies=None):
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {"model": self.model, "messages": [{"role": "user", "content": prompt}], "temperature": 0.9, "max_tokens": 200}
        for attempt in range(3):
            try:
                res = requests.post(MISTRAL_API_URL, headers=headers, json=payload, timeout=20, proxies=proxies, verify=False)
                if res.status_code == 200: return res.json()["choices"][0]["message"]["content"].strip()
                elif res.status_code == 429: time.sleep(15)
                else: break
            except: time.sleep(5)
        return None

    def phan_tich_bai_viet(self, text, proxies=None):
        if not text or len(text) < 10: return "LIKE", "Hay quá!"
        prompt = f"""Bạn là một người dùng Facebook GenZ thực thụ, nói chuyện tự nhiên, có thể viết tắt (teencode) nhẹ và dùng icon chính xác với ngữ cảnh.
        Bài viết vừa đọc: "{text}"
        Nhiệm vụ:
        1. Chọn 1 cảm xúc phù hợp (chỉ được chọn: LIKE, LOVE, HAHA, WOW, SAD, ANGRY - BẮT BUỘC VIẾT HOA).
        2. Viết 1 câu bình luận ngắn (dưới 15 chữ).
        Trả về ĐÚNG định dạng JSON (không kèm markdown):
        {{"reaction": "CẢM_XÚC_VIẾT_HOA", "comment": "NỘI_DUNG"}}"""
        ket_qua = self._goi_ai(prompt, proxies)
        if ket_qua:
            try:
                data = json.loads(ket_qua.replace("```json", "").replace("```", "").strip())
                return data.get("reaction", "LIKE"), data.get("comment", "Hay quá!")
            except: pass
        return "LIKE", "Hay quá bạn ơi! ❤️"

    def tao_bai_dang(self, chu_de, proxies=None):
        prompt = f"""Bạn là một người dùng Facebook GenZ Việt Nam.
        Viết bài đăng Facebook về chủ đề: "{chu_de}".
        Yêu cầu: 3-5 câu, phong cách GenZ, tình cảm, tự nhiên, có thể dùng teencode. Thêm icon chính xác.
        TUYỆT ĐỐI KHÔNG tự bịa hashtag linh tinh. Cuối bài CHỈ ĐƯỢC PHÉP dùng duy nhất hashtag: #teungheui_bot09"""
        ket_qua = self._goi_ai(prompt, proxies)
        return ket_qua if ket_qua else f"Hôm nay thật tuyệt! #teungheui_bot09"

def get_feed_posts(session, uid, fb_dtsg, jazoest, lsd, proxies=None):
    url = "https://www.facebook.com/api/graphql/"
    headers = {"content-type": "application/x-www-form-urlencoded", "x-fb-friendly-name": "CometNewsFeedPaginationQuery", "x-fb-lsd": lsd if lsd else "", "origin": "https://www.facebook.com", "referer": "https://www.facebook.com/"}
    variables = {"count": 10, "cursor": None, "feedLocation": "NEWSFEED", "feedbackSource": 1, "orderby": ["TOP_STORIES"], "renderLocation": "homepage_stream", "scale": 3, "stream_initial_count": 1, "useDefaultActor": False}
    data = {"av": uid, "fb_dtsg": fb_dtsg, "jazoest": jazoest, "lsd": lsd, "__user": uid, "__a": "1", "fb_api_caller_class": "RelayModern", "fb_api_req_friendly_name": "CometNewsFeedPaginationQuery", "variables": json.dumps(variables, separators=(',', ':')), "doc_id": "29228242493495109", "server_timestamps": "true"}
    try:
        res = session.post(url, headers=headers, data=data, timeout=TIMEOUT, proxies=proxies, verify=False)
        posts = []
        for line in res.text.splitlines():
            try: obj = json.loads(line)
            except: continue
            def extract(o):
                if isinstance(o, dict):
                    if "post_id" in o and isinstance(o["post_id"], str):
                        msg = ""
                        if isinstance(o.get("message"), dict) and "text" in o["message"]: msg = o["message"]["text"]
                        posts.append((o["post_id"], msg))
                    for v in o.values(): extract(v)
                elif isinstance(o, list):
                    for i in o: extract(i)
            extract(obj)
        unique_posts = []
        seen = set()
        for pid, msg in posts:
            if pid not in seen:
                seen.add(pid)
                unique_posts.append((pid, msg))
        return unique_posts
    except: return []

def graph_dang_bai(caption_text, token, proxies=None):
    url = "https://graph.facebook.com/v26.0/me/feed"
    try:
        res = requests.post(url, data={"caption": caption_text, "access_token": token}, timeout=TIMEOUT, proxies=proxies, verify=False)
        js = res.json()
        if "id" in js: return js["id"] 
        else: return None
    except Exception: return None

def graph_tha_cam_xuc(full_post_id, reaction_type, token, proxies=None):
    url = f"https://graph.facebook.com/v26.0/{full_post_id}/reactions"
    try: return requests.post(url, data={"type": reaction_type, "access_token": token}, timeout=TIMEOUT, proxies=proxies, verify=False).status_code == 200
    except: return False

def graph_comment(full_post_id, message, token, proxies=None):
    url = f"https://graph.facebook.com/v26.0/{full_post_id}/comments"
    try: return requests.post(url, data={"message": message, "access_token": token}, timeout=TIMEOUT, proxies=proxies, verify=False).status_code == 200
    except: return False

# ==========================================================
# API FLASK
# ==========================================================
def load_db():
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, 'r', encoding='utf-8') as f: return json.load(f)
        except: return []
    return []

def save_db(data):
    try:
        with open(DB_FILE, 'w', encoding='utf-8') as f: json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e: print(f"Lỗi lưu DB: {e}")

@app.route('/api/get_accounts', methods=['GET'])
def get_accounts():
    return jsonify(load_db())

@app.route('/api/add_account', methods=['POST'])
def add_account():
    data = request.json
    uid, password, twofa, proxy = data.get('uid'), data.get('pass'), data.get('twofa'), data.get('proxy', '')
    if not uid or not password: return jsonify({'success': False, 'error': 'Thiếu thông tin'})
    
    accounts = load_db()
    old_acc = next((a for a in accounts if a['uid'] == uid), None)
    device_info = old_acc.get('device_info') if old_acc else None

    proxies = parse_proxy(proxy)
    try:
        fb = facebook_login(uid_phone_mail=uid, password=password, twofactor_code=twofa, proxies=proxies, device_info=device_info)
        result = fb.login()
        
        if result['success']:
            new_acc = {
                'id': old_acc['id'] if old_acc else str(uuid.uuid4())[:8],
                'uid': uid, 'password': password, 'twofa': twofa, 'proxy': proxy,
                'fb_uid': result['cookies']['dict'].get('c_user', 'Unknown'),
                'fb_name': get_fb_name(result['access_token'], proxies),
                'status': 'Đã login', 'token_data': result, 'is_running': False,
                'device_info': result['device_info'] # Lưu lại toàn bộ thiết bị
            }
            if old_acc: accounts.remove(old_acc)
            accounts.append(new_acc)
            save_db(accounts)
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'error': result['error']})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/delete_account/<acc_id>', methods=['DELETE'])
def delete_account(acc_id):
    accounts = load_db()
    accounts = [acc for acc in accounts if acc['id'] != acc_id]
    save_db(accounts)
    return jsonify({'success': True})

@app.route('/api/get_token', methods=['POST'])
def api_get_token():
    acc_id = request.json.get('id')
    acc = next((a for a in load_db() if a['id'] == acc_id), None)
    if not acc or not acc.get('token_data'): return jsonify({'success': False, 'error': 'Chưa có token.'})
    return jsonify({'success': True, 'original_token': {'access_token': acc['token_data']['access_token']}, 'cookies': acc['token_data']['cookies']})

@app.route('/api/get_logs', methods=['POST'])
def api_get_logs():
    acc_id = request.json.get('id')
    return jsonify({'logs': bot_logs.get(acc_id, [])})

@app.route('/api/toggle_bot', methods=['POST'])
def toggle_bot():
    acc_id = request.json.get('id')
    accounts = load_db()
    acc = next((a for a in accounts if a['id'] == acc_id), None)
    
    if not acc: return jsonify({'success': False, 'error': 'Không tìm thấy tài khoản'})
    if not acc.get('token_data'): return jsonify({'success': False, 'error': 'Vui lòng đợi login lấy token trước.'})

    if acc.get('is_running'):
        acc['is_running'] = False
        acc['status'] = 'Đã Stop'
        save_db(accounts)
        if acc_id in bot_logs: bot_logs[acc_id].append(f"[HỆ THỐNG] Đã dừng nuôi acc.")
        return jsonify({'success': True, 'message': 'Đã dừng Bot', 'is_running': False})

    acc['is_running'] = True
    acc['status'] = 'Đang nuôi'
    save_db(accounts)
    bot_logs[acc_id] = [f"[HỆ THỐNG] Bắt đầu nuôi acc..."]
    
    token_data = acc['token_data']
    token_eaaa = token_data['access_token']
    cookie_dict = token_data['cookies']['dict']
    uid = cookie_dict.get("c_user", "0")
    proxies = parse_proxy(acc.get('proxy'))

    def add_log(msg):
        if acc_id not in bot_logs: bot_logs[acc_id] = []
        bot_logs[acc_id].append(msg)
        if len(bot_logs[acc_id]) > 50: bot_logs[acc_id].pop(0)

    def run_bot():
        add_log("[*] Đang thiết lập phiên...")
        session = tao_phien(cookie_dict, proxies)
        meta = lay_metadata(session, proxies)
        fb_dtsg, lsd = meta.get("fb_dtsg"), meta.get("lsd")
        
        if not fb_dtsg: 
            add_log("[-] Lỗi: Không lấy được fb_dtsg.")
            return
            
        jazoest = "2" + "".join(str(ord(c)) for c in fb_dtsg)
        add_log(f"[+] Đã lấy được token. Bắt đầu nuôi acc...")
        
        ai = facebook_ai(MISTRAL_API_KEY)
        
        session_count = 0
        last_post_session = -12 

        while acc.get('is_running'):
            session_count += 1
            add_log(f"--- Bắt đầu phiên {session_count} ---")
            
            can_post = (session_count - last_post_session) >= 12

            if can_post:
                add_log("[*] Đang đăng bài...")
                chu_de = random.choice(["tâm trạng", "tình yêu", "cuộc sống", "sự mệt mỏi", "niềm vui"])
                noi_dung = ai.tao_bai_dang(chu_de, proxies)
                
                if noi_dung:
                    add_log(f"    -> Nội dung: {noi_dung[:50]}...")
                    post_id = graph_dang_bai(noi_dung, token_eaaa, proxies)
                    if post_id:
                        add_log(f"    ✅ https://www.facebook.com/{post_id}")
                        last_post_session = session_count
                    else:
                        add_log("    ❌ Đăng bài thất bại.")
                
                time.sleep(random.uniform(120, 180)) 
            
            add_log("[*] Đang quét bài viết trên Feed...")
            posts = get_feed_posts(session, uid, fb_dtsg, jazoest, lsd, proxies)
            
            if posts:
                so_lan_tuong_tac = random.randint(5, 7)
                selected_posts = random.sample(posts, min(len(posts), so_lan_tuong_tac))
                add_log(f"[*] Bắt đầu thả cảm xúc và bình luận {len(selected_posts)} bài...")
                
                for pid, msg in selected_posts:
                    if not acc.get('is_running'): break
                    full_pid = f"{uid}_{pid}" if "_" not in pid else pid
                    time.sleep(random.uniform(10, 15))
                    
                    reaction, comment = ai.phan_tich_bai_viet(msg, proxies)
                    add_log(f"    -> Bài: {pid} | Nội dung: {msg[:30]}...")
                    add_log(f"       AI chọn: {reaction} | Cmt: {comment}")
                    
                    ok_rx = graph_tha_cam_xuc(full_pid, reaction, token_eaaa, proxies)
                    time.sleep(random.uniform(2, 4))
                    ok_cmt = graph_comment(full_pid, comment, token_eaaa, proxies)
                    
                    if ok_rx and ok_cmt:
                        add_log(f"    ✅ https://www.facebook.com/{pid}")
                    
                    time.sleep(random.uniform(240, 300))
            else:
                add_log("[!] Không tìm thấy bài viết nào trên Feed.")

            add_log(f"--- Kết thúc phiên {session_count} ---")

    thread = threading.Thread(target=run_bot)
    thread.daemon = True
    running_bots[acc_id] = thread
    thread.start()
    
    return jsonify({'success': True, 'message': 'Đã bắt đầu Bot', 'is_running': True})

@app.route('/')
def index():
    paths = ['index.html', 'assets/index.html', os.path.join(os.path.dirname(__file__), 'index.html'), os.path.join(os.path.dirname(__file__), 'assets', 'index.html')]
    for p in paths:
        if os.path.exists(p): return send_from_directory(os.path.dirname(p) if os.path.dirname(p) else '.', os.path.basename(p))
    return "Lỗi: Không tìm thấy file index.html", 404

def run_server():
    def run():
        app.run(host='127.0.0.1', port=8080, threaded=True, use_reloader=False, debug=False)
    t = threading.Thread(target=run)
    t.daemon = True
    t.start()

if __name__ == '__main__':
    run_server()
    while True: time.sleep(1)