import random, string, json, time, uuid, base64, io, struct, re, os, threading
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from Crypto.Cipher import AES, PKCS1_v1_5
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ===== HTTP client: curl_cffi cho web/GraphQL, requests cho Graph API =====
try:
    from curl_cffi import requests as crequests
    _HAS_CURL_CFFI = True
except Exception:
    import requests as crequests  # fallback (vẫn chạy nhưng dễ bị flag hơn)
    _HAS_CURL_CFFI = False
import requests  # dùng cho Graph API + check proxy

app = Flask(__name__, static_folder=".")
CORS(app)

# ===== Cấu hình =====
SHOW_RAW_RESPONSE = False
TIMEOUT = 20
MISTRAL_API_KEY = os.environ.get(
    "MISTRAL_API_KEY",
    "mstrl_N4uIpAyBTp3TNxDOPdLAfp64R1Sl9UVx_3DK7oj",
)
MISTRAL_API_URL = "https://api.mistral.ai/v1/chat/completions"
MODEL_AI = "mistral-tiny"

# UA Chrome thật dùng cho web session (Hướng A)
CHROME_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)
CHROME_IMPERSONATE = "chrome124"
CHROME_SEC_CH_UA = '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"'

# UA Dalvik chỉ dùng cho bước login app (b-graph) để lấy token/cookie
DEFAULT_DALVIK_UA = (
    "Dalvik/2.1.0 (Linux; U; Android 9; 23113RKC6C Build/PQ3A.190705.08211809) "
    "[FBAN/FB4A;FBAV/417.0.0.33.65;FBPN/com.facebook.katana;FBLC/vi_VN;"
    "FBBV/480086274;FBCR/MobiFone;FBMF/Redmi;FBBD/Redmi;FBDV/23113RKC6C;"
    "FBSV/9;FBCA/x86:armeabi-v7a;FBDM/{density=1.5,width=1280,height=720};"
    "FB_FW/1;FBRV/0;]"
)

# ===== Đường dẫn lưu trữ =====
def get_safe_android_path():
    for path in [
        "/storage/emulated/0/Download/SnowPanel_Data",
        "/sdcard/Download/SnowPanel_Data",
        "/storage/emulated/0/Documents/SnowPanel_Data",
        "/sdcard/Documents/SnowPanel_Data",
    ]:
        try:
            os.makedirs(path, exist_ok=True)
            open(os.path.join(path, ".test"), "w").write("1")
            os.remove(os.path.join(path, ".test"))
            return path
        except Exception:
            pass
    return os.path.dirname(os.path.abspath(__file__))

BASE_DIR = get_safe_android_path()
DEVICE_POOL_FILE = os.path.join(BASE_DIR, "device_pool.json")
NOTIFY_FILE = os.path.join(BASE_DIR, "notifications.json")

running_bots = {}
bot_logs = {}

_file_lock = threading.Lock()
_bot_lock = threading.Lock()

# ===== Thông báo =====
def save_notification(title, content):
    with _file_lock:
        notifications = []
        if os.path.exists(NOTIFY_FILE):
            try:
                notifications = json.load(open(NOTIFY_FILE, "r", encoding="utf-8"))
            except Exception:
                notifications = []
        now = time.time()
        notifications = [n for n in notifications if now - n.get("timestamp", 0) < 30 * 24 * 3600]
        notifications.insert(0, {
            "title": title,
            "content": content,
            "time": time.strftime("%H:%M:%S - %d/%m/%Y"),
            "timestamp": now,
        })
        try:
            tmp = NOTIFY_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(notifications, f, ensure_ascii=False, indent=2)
            os.replace(tmp, NOTIFY_FILE)
        except Exception:
            pass

def get_notifications():
    with _file_lock:
        if os.path.exists(NOTIFY_FILE):
            try:
                return json.load(open(NOTIFY_FILE, "r", encoding="utf-8"))
            except Exception:
                return []
        return []

# ===== Device pool =====
def load_device_pool():
    if os.path.exists(DEVICE_POOL_FILE):
        try:
            return json.load(open(DEVICE_POOL_FILE, "r", encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_device_pool(data):
    with _file_lock:
        try:
            tmp = DEVICE_POOL_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, DEVICE_POOL_FILE)
        except Exception:
            pass

def get_pinned_device(email, datr=None):
    """
    Luôn dùng device cũ nếu đã có (không ghi đè bằng datr).
    datr chỉ dùng để set cookie datr cho session login, KHÔNG gán vào machine_id.
    """
    pool = load_device_pool()
    if email in pool:
        return pool[email]
    device = {
        "device_id": str(uuid.uuid4()),
        "adid": str(uuid.uuid4()),
        "secure_family_device_id": str(uuid.uuid4()),
        "jazoest": "".join(random.choices(string.digits, k=5)),
        "sim_serial": "".join(random.choices(string.digits, k=20)),
        "user_agent": DEFAULT_DALVIK_UA,
        "machine_id": "".join(random.choices(string.ascii_letters + string.digits, k=24)),
        "last_login": time.time(),
    }
    pool[email] = device
    save_device_pool(pool)
    return device

# ===== Proxy =====
def parse_proxy(proxy_str):
    if not proxy_str or proxy_str.strip() == "":
        return None
    p = proxy_str.strip()
    if "://" in p:
        return {"http": p, "https": p}
    parts = p.split(":")
    if len(parts) == 4:
        u = f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
        return {"http": u, "https": u}
    elif len(parts) == 3:
        # ip:port:user -> không có pass, hiếm dùng
        u = f"http://{parts[2]}@{parts[0]}:{parts[1]}"
        return {"http": u, "https": u}
    elif len(parts) == 2:
        u = f"http://{parts[0]}:{parts[1]}"
        return {"http": u, "https": u}
    return {"http": f"http://{p}", "https": f"http://{p}"}

# ===== Graph API helpers (dùng requests) =====
def get_fb_name(token, proxies=None):
    try:
        res = requests.get(
            "https://graph.facebook.com/v18.0/me",
            params={"fields": "id,name", "access_token": token},
            proxies=proxies, timeout=10,
        )
        if res.status_code == 200:
            return res.json().get("name", "❌ Không lấy được tên")
        return "❌ Token lỗi"
    except Exception:
        return "❌ Lỗi mạng"

def check_live_die(token, proxies=None):
    """Chỉ trả False khi CHẮC CHẮN token chết (400/401/403). Lỗi mạng -> None (không kết luận)."""
    try:
        res = requests.get(
            "https://graph.facebook.com/v18.0/me",
            params={"access_token": token},
            proxies=proxies, timeout=10,
        )
        if res.status_code == 200:
            return True
        if res.status_code in (400, 401, 403):
            return False
        return None
    except Exception:
        return None

def check_alive_by_session(session, proxies=None):
    """Check sống chết bằng session web. True/False/None (không kết luận)."""
    try:
        r = session.get(
            "https://www.facebook.com/me",
            timeout=10, proxies=proxies, allow_redirects=False,
        )
        loc = (r.headers.get("Location") or "").lower()
        if r.status_code == 200 and "checkpoint" not in loc and "login" not in loc:
            return True
        if r.status_code in (301, 302, 303, 307, 308):
            if "login" in loc or "checkpoint" in loc:
                return False
            return True
        if r.status_code in (401, 403):
            return False
        return None
    except Exception:
        return None

# ===== Encrypt password =====
class facebook_password_encryptor:
    @staticmethod
    def get_public_key(proxies=None):
        try:
            url = "https://b-graph.facebook.com/pwd_key_fetch"
            params = {
                "version": "2", "flow": "CONTROLLER_INITIALIZATION",
                "method": "GET", "fb_api_req_friendly_name": "pwdKeyFetch",
                "fb_api_caller_class": "com.facebook.auth.login.AuthOperations",
                "access_token": "438142079694454|fc0a7caa49b192f64f6f5a6d9643bb28",
            }
            res = requests.post(url, params=params, proxies=proxies, timeout=TIMEOUT).json()
            return res.get("public_key"), str(res.get("key_id", "25"))
        except Exception:
            return None, "25"

    @staticmethod
    def encrypt(password, public_key=None, key_id="25", proxies=None):
        """Trả về chuỗi #PWD_FB4A... hoặc raise nếu fail (KHÔNG fallback plaintext)."""
        if public_key is None:
            public_key, key_id = facebook_password_encryptor.get_public_key(proxies)
        if not public_key:
            raise RuntimeError("Không lấy được public key để mã hóa password. Kiểm tra proxy/mạng.")
        try:
            rand_key = get_random_bytes(32)
            iv = get_random_bytes(12)
            pubkey = RSA.import_key(public_key)
            cipher_rsa = PKCS1_v1_5.new(pubkey)
            encrypted_rand_key = cipher_rsa.encrypt(rand_key)
            cipher_aes = AES.new(rand_key, AES.MODE_GCM, nonce=iv)
            current_time = int(time.time())
            cipher_aes.update(str(current_time).encode("utf-8"))
            encrypted_passwd, auth_tag = cipher_aes.encrypt_and_digest(password.encode("utf-8"))
            buf = io.BytesIO()
            buf.write(bytes([1, int(key_id)]))
            buf.write(iv)
            buf.write(struct.pack("<h", len(encrypted_rand_key)))
            buf.write(encrypted_rand_key)
            buf.write(auth_tag)
            buf.write(encrypted_passwd)
            return f"#PWD_FB4A:2:{current_time}:{base64.b64encode(buf.getvalue()).decode('utf-8')}"
        except Exception as e:
            raise RuntimeError(f"Encrypt password thất bại: {e}")

# ===== App tokens =====
class FacebookAppTokens:
    APPS = {
        "FB_ANDROID": {"app_id": "350685531728"},
        "MESSENGER_ANDROID": {"app_id": "256002347743983"},
        "FB_LITE": {"app_id": "275254692598279"},
        "MESSENGER_LITE": {"app_id": "200424423651082"},
        "ADS_MANAGER_ANDROID": {"app_id": "438142079694454"},
        "PAGES_MANAGER_ANDROID": {"app_id": "121876164619130"},
    }
    NEEDED_APPS = ["FB_ANDROID", "MESSENGER_ANDROID"]

    @staticmethod
    def get_app_id(app_key):
        return FacebookAppTokens.APPS.get(app_key, {}).get("app_id")

    @staticmethod
    def get_all_app_keys():
        return list(FacebookAppTokens.APPS.keys())

    @staticmethod
    def extract_token_prefix(token):
        for i, char in enumerate(token):
            if char.islower():
                return token[:i]
        return token

# ===== Login =====
class facebook_login:
    API_URL = "https://b-graph.facebook.com/auth/login"
    ACCESS_TOKEN = "350685531728|62f8ce9f74b12f84c123cc23437a4a32"
    API_KEY = "882a8490361da98702bf97a021ddc14d"
    SIG = "214049b9f17c38bd767de53752b53946"
    BASE_HEADERS = {
        "content-type": "application/x-www-form-urlencoded",
        "x-fb-net-hni": "45201", "zero-rated": "0", "x-fb-sim-hni": "45201",
        "x-fb-connection-quality": "EXCELLENT", "x-fb-friendly-name": "authenticate",
        "x-fb-connection-bandwidth": "78032897", "x-tigon-is-retry": "False",
        "authorization": "OAuth null", "x-fb-connection-type": "WIFI",
        "x-fb-device-group": "3342", "priority": "u=3,i",
        "x-fb-http-engine": "Liger", "x-fb-client-ip": "True",
        "x-fb-server-cluster": "True",
    }

    def __init__(self, uid_phone_mail, password, twofactor_code=None, proxies=None, datr=None):
        self.uid_phone_mail = uid_phone_mail
        self.twofactor_code = twofactor_code
        self.proxies = proxies
        self.datr = (datr or "").strip()
        pinned = get_pinned_device(uid_phone_mail)
        self.machine_id = pinned["machine_id"]
        self.device_id = pinned["device_id"]
        self.adid = pinned["adid"]
        self.secure_family_device_id = pinned["secure_family_device_id"]
        self.jazoest = pinned["jazoest"]
        self.sim_serial = pinned["sim_serial"]
        self.user_agent = pinned["user_agent"]
        if password.startswith("#PWD_FB4A"):
            self.password = password
        else:
            self.password = facebook_password_encryptor.encrypt(password, proxies=proxies)
        self.session = requests.Session()
        if self.proxies:
            self.session.proxies.update(self.proxies)
        if self.datr:
            # Hâm login bằng cookie datr (giúp giảm checkpoint)
            self.session.cookies.set("datr", self.datr, domain=".facebook.com")
        self.headers = self._build_headers()
        self.data = self._build_data()

    def _build_headers(self):
        headers = self.BASE_HEADERS.copy()
        headers.update({
            "x-fb-request-analytics-tags": json.dumps({
                "network_tags": {"product": "350685531728", "retry_attempt": "0"},
                "application_tags": "unknown",
            }),
            "user-agent": self.user_agent,
        })
        return headers

    def _build_data(self):
        return {
            "format": "json", "email": self.uid_phone_mail, "password": self.password,
            "credentials_type": "password", "generate_session_cookies": "1",
            "api_key": self.API_KEY, "access_token": self.ACCESS_TOKEN,
            "adid": self.adid, "device_id": self.device_id,
            "generate_analytics_claim": "1", "community_id": "",
            "linked_guest_account_userid": "", "cpl": "true", "try_num": "1",
            "family_device_id": self.device_id,
            "secure_family_device_id": self.secure_family_device_id,
            "sim_serials": f'["{self.sim_serial}"]',
            "openid_flow": "android_login", "openid_provider": "google",
            "openid_tokens": "[]",
            "account_switcher_uids": f'["{self.uid_phone_mail}"]',
            "fb4a_shared_phone_cpl_experiment": "fb4a_shared_phone_nonce_cpl_at_risk_v3",
            "fb4a_shared_phone_cpl_group": "enable_v3_at_risk",
            "enroll_misauth": "false", "error_detail_type": "button_with_disabled",
            "source": "login", "machine_id": self.machine_id,
            "jazoest": self.jazoest, "meta_inf_fbmeta": "V2_UNTAGGED",
            "advertiser_id": self.adid, "encrypted_msisdn": "",
            "currently_logged_in_userid": "0",
            "fb_api_req_friendly_name": "authenticate",
            "fb_api_caller_class": "Fb4aAuthHandler", "sig": self.SIG,
        }

    def _convert_token(self, access_token, target_app):
        try:
            app_id = FacebookAppTokens.get_app_id(target_app)
            if not app_id:
                return None
            response = requests.post(
                "https://api.facebook.com/method/auth.getSessionforApp",
                data={
                    "access_token": access_token, "format": "json",
                    "new_app_id": app_id, "generate_session_cookies": "1",
                },
                proxies=self.proxies, timeout=15,
            )
            result = response.json()
            if "access_token" in result:
                token = result["access_token"]
                prefix = FacebookAppTokens.extract_token_prefix(token)
                cookies_dict = {}
                cookies_string = ""
                if "session_cookies" in result:
                    for cookie in result["session_cookies"]:
                        cookies_dict[cookie["name"]] = cookie["value"]
                        cookies_string += f"{cookie['name']}={cookie['value']}; "
                return {
                    "token_prefix": prefix,
                    "access_token": token,
                    "cookies": {"dict": cookies_dict, "string": cookies_string.rstrip("; ")},
                }
            return None
        except Exception:
            return None

    def _parse_success(self, res_json):
        c_dict, c_str = {}, ""
        if "session_cookies" in res_json:
            for c in res_json["session_cookies"]:
                c_dict[c["name"]] = c["value"]
                c_str += f"{c['name']}={c['value']}; "
        original_token = res_json["access_token"]
        result = {
            "success": True,
            "original_token": {
                "token_prefix": FacebookAppTokens.extract_token_prefix(original_token),
                "access_token": original_token,
            },
            "cookies": {"dict": c_dict, "string": c_str.rstrip("; ")},
            "user_agent": self.user_agent,
            "converted_tokens": {},
        }
        for target_app in FacebookAppTokens.NEEDED_APPS:
            converted = self._convert_token(original_token, target_app)
            if converted:
                result["converted_tokens"][target_app] = converted
        return result

    def _handle_2fa(self, error_data):
        if not self.twofactor_code:
            return {"success": False, "error": "❌ Yêu cầu 2FA nhưng chưa nhập mã."}
        data_2fa = self._build_data()
        data_2fa.update({
            "credentials_type": "two_factor",
            "twofactor_code": self.twofactor_code,
            "first_factor": error_data.get("login_first_factor"),
            "userid": error_data.get("uid"),
        })
        try:
            res = self.session.post(
                self.API_URL, headers=self.headers, data=data_2fa,
                proxies=self.proxies, timeout=TIMEOUT,
            ).json()
            if "access_token" in res:
                return self._parse_success(res)
            return {"success": False, "error": res.get("error", {}).get("message", "❌ Mã 2FA sai")}
        except Exception as e:
            return {"success": False, "error": f"Lỗi 2FA: {e}"}

    def login(self):
        try:
            if self.proxies:
                try:
                    requests.get("https://api.ipify.org", proxies=self.proxies, timeout=10)
                except Exception:
                    return {"success": False, "error": "Proxy không phản hồi (Timeout)"}
            try:
                response = self.session.post(
                    self.API_URL, headers=self.headers, data=self.data,
                    proxies=self.proxies, timeout=TIMEOUT,
                )
            except requests.exceptions.Timeout:
                return {"success": False, "error": "❌ Facebook không phản hồi (Timeout)"}
            except requests.exceptions.ProxyError:
                return {"success": False, "error": "❌ Facebook chặn Proxy"}
            except Exception as e:
                return {"success": False, "error": f"❌ Lỗi mạng: {str(e)}"}
            response_json = response.json()
            if "access_token" in response_json:
                if not response_json["access_token"].startswith("EAAA"):
                    return {"success": False, "error": "Token không phải EAAA"}
                return self._parse_success(response_json)
            if "error" in response_json:
                err_data = response_json["error"].get("error_data", {})
                if "login_first_factor" in err_data and "uid" in err_data:
                    return self._handle_2fa(err_data)
                err_msg = response_json["error"].get("message", "❌ Lỗi không xác định")
                if "abusive" in err_msg.lower():
                    return {
                        "success": False,
                        "error": "❌❌ ACC BỊ DÍNH SPAM LOGIN (ABUSIVE). VUI LÒNG NGÂM ACC TRONG 3 NGÀY HOẶC DÙNG 'datr' ĐỂ LOGIN!",
                    }
                return {"success": False, "error": err_msg}
            return {"success": False, "error": "❌ Sai định dạng phản hồi"}
        except Exception as e:
            return {"success": False, "error": f"❌ Lỗi Python: {str(e)}"}

# ===== Web session helpers (Hướng A) =====
def _chrome_web_headers(referer="https://www.facebook.com/"):
    return {
        "User-Agent": CHROME_UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
        "sec-ch-ua": CHROME_SEC_CH_UA,
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-User": "?1",
        "Sec-Fetch-Dest": "document",
        "Upgrade-Insecure-Requests": "1",
        "Referer": referer,
    }

def _graphql_headers(referer="https://www.facebook.com/", lsd=""):
    return {
        "content-type": "application/x-www-form-urlencoded",
        "User-Agent": CHROME_UA,
        "Accept": "*/*",
        "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
        "x-fb-friendly-name": "CometNewsFeedPaginationQuery",
        "x-fb-lsd": lsd or "",
        "origin": "https://www.facebook.com",
        "referer": referer,
        "sec-ch-ua": CHROME_SEC_CH_UA,
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
    }

def tao_phien(c_dict, user_agent=None, proxies=None):
    """Tạo session web bằng curl_cffi impersonate Chrome. user_agent bị bỏ qua (dùng CHROME_UA)."""
    if _HAS_CURL_CFFI:
        s = crequests.Session(impersonate=CHROME_IMPERSONATE)
    else:
        s = crequests.Session()
        s.headers.update({"User-Agent": CHROME_UA})
    s.headers.update(_chrome_web_headers())
    for k, v in c_dict.items():
        try:
            s.cookies.set(k, v, domain=".facebook.com")
        except Exception:
            pass
    if proxies:
        s.proxies.update(proxies)
    return s

def lay_metadata(s, proxies=None):
    meta = {"fb_dtsg": None, "lsd": None}
    try:
        r = s.get("https://www.facebook.com/", timeout=TIMEOUT, proxies=proxies)
        m = re.search(r'"DTSGInitialData":\{"token":"(.*?)"', r.text) or \
            re.search(r'\["DTSGInitialData",\[\],\{"token":"(.*?)"\}', r.text)
        if m:
            meta["fb_dtsg"] = m.group(1)
        m = re.search(r'"LSD":\{"token":"(.*?)"', r.text) or \
            re.search(r'\["LSD",\[\],\{"token":"(.*?)"\}', r.text)
        if m:
            meta["lsd"] = m.group(1)
    except Exception:
        pass
    if not meta["fb_dtsg"]:
        try:
            r = s.get("https://business.facebook.com/", timeout=TIMEOUT, proxies=proxies)
            m = re.search(r'name="fb_dtsg" value="([^"]+)"', r.text) or \
                re.search(r'"DTSGInitialData",\[\],\{"token":"([^"]+)"', r.text)
            if m:
                meta["fb_dtsg"] = m.group(1)
        except Exception:
            pass
    return meta

# ===== AI =====
class facebook_ai:
    def __init__(self, api_key):
        self.api_key = api_key
        self.model = MODEL_AI

    def _goi_ai(self, prompt, proxies=None):
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.9, "max_tokens": 200,
        }
        for _ in range(3):
            try:
                res = requests.post(MISTRAL_API_URL, headers=headers, json=payload, timeout=20, proxies=proxies)
                if res.status_code == 200:
                    return res.json()["choices"][0]["message"]["content"].strip()
                elif res.status_code == 429:
                    time.sleep(15)
                else:
                    break
            except Exception:
                time.sleep(5)
        return None

    def phan_tich_bai_viet(self, text, proxies=None):
        if not text or len(text.strip()) < 5:
            fallback_comments = [
                "Đẹp quá trời 😍", "Xinh xỉu 💖", "Nhìn mê quá đi 🥰",
                "Video hay quá ạ 👏", "Ảnh xịn quá 😎", "Chuẩn luôn anh ơi 👍",
            ]
            return "LOVE", random.choice(fallback_comments), "Bài viết không có text (Ảnh/Video)"
        prompt = (
            f'Bạn là một người dùng Facebook GenZ thực thụ. Bài viết: "{text}". '
            'Nhiệm vụ: 1. Chọn cảm xúc (LIKE, LOVE, HAHA, WOW, SAD, ANGRY). '
            '2. Bình luận ngắn dưới 15 chữ. YÊU CẦU: Chỉ trả về JSON: '
            '{"reaction": "CẢM_XÚC", "comment": "NỘI_DUNG"}'
        )
        ket_qua = self._goi_ai(prompt, proxies)
        raw_resp = ket_qua if ket_qua else "Lỗi gọi API AI"
        if ket_qua:
            try:
                match = re.search(r'\{.*?\}', ket_qua.replace("\n", " "), re.IGNORECASE)
                if match:
                    data = json.loads(match.group(0))
                    if "reaction" in data and "comment" in data:
                        return str(data["reaction"]).upper(), str(data["comment"]), raw_resp
            except Exception:
                pass
        return "LIKE", "Hay quá bạn ơi! ❤️", raw_resp

    def tao_bai_dang(self, chu_de, proxies=None):
        prompt = (
            f'Bạn là một người dùng Facebook GenZ Việt Nam. Viết bài đăng Facebook về chủ đề: "{chu_de}". '
            "Yêu cầu: 3-5 câu, phong cách GenZ, tình cảm, tự nhiên, có thể dùng teencode. "
            "Thêm icon chính xác. TUYỆT ĐỐI KHÔNG dùng định dạng Markdown (không dùng dấu **, không dùng #). "
            "BÀI VIẾT DÀI CÙNG LẮM LÀ 3 DÒNG THÔI. QUY TẮC ĐẶT HASHTAG: "
            "- TUYỆT ĐỐI KHÔNG tự bịa ra bất kỳ hashtag nào khác. "
            "- Dòng cuối cùng BẮT BUỘC: #teungheui_bot09"
        )
        ket_qua = self._goi_ai(prompt, proxies)
        return ket_qua if ket_qua else "Hôm nay thật tuyệt! #teungheui_bot09"

# ===== GraphQL feed =====
def get_feed_posts(session, uid, fb_dtsg, jazoest, lsd, proxies=None):
    url = "https://www.facebook.com/api/graphql/"
    headers = _graphql_headers(referer="https://www.facebook.com/", lsd=lsd)
    headers["x-fb-friendly-name"] = "CometNewsFeedPaginationQuery"
    variables = {
        "RELAY_INCREMENTAL_DELIVERY": True, "clientQueryId": str(uuid.uuid4()),
        "connectionClass": "GOOD", "count": 10, "cursor": None,
        "feedLocation": "NEWSFEED", "feedStyle": "DEFAULT", "feedbackSource": 1,
        "orderby": ["TOP_STORIES"], "privacySelectorRenderLocation": "COMET_STREAM",
        "refreshMode": "AUTO", "renderLocation": "homepage_stream", "scale": 3,
        "useDefaultActor": False,
    }
    data = {
        "av": uid, "fb_dtsg": fb_dtsg, "jazoest": jazoest, "lsd": lsd,
        "__user": uid, "__a": "1",
        "fb_api_caller_class": "RelayModern",
        "fb_api_req_friendly_name": "CometNewsFeedPaginationQuery",
        "variables": json.dumps(variables, separators=(",", ":")),
        "doc_id": "39846308615014480",
        "server_timestamps": "true",
    }
    try:
        res = session.post(url, headers=headers, data=data, timeout=TIMEOUT, proxies=proxies)
        raw_text = res.text
        posts = []

        def extract(o):
            if isinstance(o, dict):
                if "post_id" in o and isinstance(o["post_id"], str):
                    msg = ""
                    author_id = ""
                    if isinstance(o.get("message"), dict) and "text" in o["message"]:
                        msg = o["message"]["text"]
                    elif "message" in o and isinstance(o["message"], str):
                        msg = o["message"]
                    if isinstance(o.get("actors"), list) and len(o["actors"]) > 0:
                        author_id = str(o["actors"][0].get("id", ""))
                    posts.append((o["post_id"], msg, author_id))
                for v in o.values():
                    extract(v)
            elif isinstance(o, list):
                for i in o:
                    extract(i)

        for line in raw_text.splitlines():
            try:
                obj = json.loads(line)
            except Exception:
                continue
            extract(obj)

        unique_posts, seen = [], set()
        for pid, msg, author_id in posts:
            if pid in seen:
                continue
            seen.add(pid)
            if author_id != uid:
                unique_posts.append((pid, msg, author_id))
        if SHOW_RAW_RESPONSE:
            return unique_posts, f"RAW FEED: {raw_text[:300]}..."
        if not unique_posts:
            return "ERROR_RESPONSE: " + raw_text[:500]
        return unique_posts
    except Exception as e:
        return "ERROR_EXCEPTION: " + str(e)

def _build_full_post_id(pid, author_id=None):
    """Trả về full post id dạng author_post. Nếu pid đã có '_' thì giữ nguyên."""
    if "_" in pid:
        return pid
    if author_id:
        return f"{author_id}_{pid}"
    return pid

def format_post_link(pid, uid, author_id=None):
    if author_id == uid:
        return f"https://www.facebook.com/{uid}"
    if "_" in pid:
        parts = pid.split("_")
        return f"https://www.facebook.com/{parts[0]}/posts/{parts[1]}"
    else:
        return f"https://www.facebook.com/{uid}/posts/{pid}"

# ===== Graph API actions =====
def graph_dang_bai(caption_text, token, proxies=None):
    try:
        res = requests.post(
            "https://graph.facebook.com/v26.0/me/feed",
            data={"message": caption_text, "access_token": token, "privacy": '{"value":"EVERYONE"}'},
            timeout=TIMEOUT, proxies=proxies,
        )
        js = res.json()
        return js.get("id") if "id" in js else "ERROR: " + str(js.get("error", {}).get("message", "Unknown"))
    except Exception as e:
        return "EXCEPTION: " + str(e)

def graph_tha_cam_xuc(full_post_id, reaction_type, token, proxies=None):
    try:
        res = requests.post(
            f"https://graph.facebook.com/v26.0/{full_post_id}/reactions",
            data={"type": reaction_type, "access_token": token},
            timeout=TIMEOUT, proxies=proxies,
        )
        return True if res.status_code == 200 else "Lỗi FB: " + res.text[:100]
    except Exception as e:
        return "Lỗi mạng: " + str(e)

def graph_comment(full_post_id, message, token, proxies=None):
    try:
        res = requests.post(
            f"https://graph.facebook.com/v26.0/{full_post_id}/comments",
            data={"message": message, "access_token": token},
            timeout=TIMEOUT, proxies=proxies,
        )
        return True if res.status_code == 200 else "Lỗi FB: " + res.text[:100]
    except Exception as e:
        return "Lỗi mạng: " + str(e)

# ===== Kết bạn qua GraphQL web (thay endpoint Graph API không tồn tại) =====
FRIEND_REQUEST_DOC_ID = ""  # để trống -> báo lỗi rõ ràng; bạn cần điền doc_id thực tế

def graphql_ket_ban(session, uid, fb_dtsg, jazoest, lsd, target_id, proxies=None):
    if not FRIEND_REQUEST_DOC_ID:
        return "Lỗi cấu hình: chưa có FRIEND_REQUEST_DOC_ID (lấy từ network tab trình duyệt thật)"
    url = "https://www.facebook.com/api/graphql/"
    headers = _graphql_headers(referer="https://www.facebook.com/friends/", lsd=lsd)
    headers["x-fb-friendly-name"] = "FriendingCometFriendRequestSendMutation"
    variables = {"input": {"friend_requestee_ids": [target_id], "source": "friend_center"}}
    data = {
        "av": uid, "fb_dtsg": fb_dtsg, "jazoest": jazoest, "lsd": lsd,
        "__user": uid, "__a": "1",
        "fb_api_caller_class": "RelayModern",
        "fb_api_req_friendly_name": "FriendingCometFriendRequestSendMutation",
        "variables": json.dumps(variables, separators=(",", ":")),
        "doc_id": FRIEND_REQUEST_DOC_ID,
        "server_timestamps": "true",
    }
    try:
        r = session.post(url, headers=headers, data=data, timeout=TIMEOUT, proxies=proxies)
        if r.status_code == 200 and '"errors"' not in r.text:
            return True
        return "GraphQL lỗi: " + r.text[:150]
    except Exception as e:
        return "Lỗi mạng: " + str(e)

def get_suggested_friends(session, uid, fb_dtsg, jazoest, lsd, proxies=None):
    url = "https://www.facebook.com/api/graphql/"
    headers = _graphql_headers(referer="https://www.facebook.com/friends/", lsd=lsd)
    headers["x-fb-friendly-name"] = "PeopleYouMayKnowPaginationQuery"
    variables = {"count": 10, "cursor": None, "scale": 3, "useDefaultActor": False}
    data = {
        "av": uid, "fb_dtsg": fb_dtsg, "jazoest": jazoest, "lsd": lsd,
        "__user": uid, "__a": "1",
        "fb_api_caller_class": "RelayModern",
        "fb_api_req_friendly_name": "PeopleYouMayKnowPaginationQuery",
        "variables": json.dumps(variables, separators=(",", ":")),
        "doc_id": "28614045121363201", "server_timestamps": "true",
    }
    try:
        res = session.post(url, headers=headers, data=data, timeout=TIMEOUT, proxies=proxies)
        users = []

        def extract_user(o):
            if isinstance(o, dict):
                if o.get("__typename") == "User" and isinstance(o.get("id"), str) and o["id"].isdigit():
                    users.append(o["id"])
                for v in o.values():
                    extract_user(v)
            elif isinstance(o, list):
                for i in o:
                    extract_user(i)

        for line in res.text.splitlines():
            try:
                obj = json.loads(line)
            except Exception:
                continue
            extract_user(obj)
        return list(set(users))
    except Exception:
        return []

# ===== ROUTES (giữ nguyên path & tên) =====
@app.route("/api/toggle_setting", methods=["POST"])
def toggle_setting():
    global SHOW_RAW_RESPONSE
    data = request.json or {}
    if "show_raw_response" in data:
        SHOW_RAW_RESPONSE = data["show_raw_response"]
    return jsonify({"success": True, "show_raw_response": SHOW_RAW_RESPONSE})

@app.route("/api/get_settings", methods=["GET"])
def get_settings():
    return jsonify({"show_raw_response": SHOW_RAW_RESPONSE})

@app.route("/api/get_notifications", methods=["GET"])
def api_get_notifications():
    return jsonify({"notifications": get_notifications()})

@app.route("/api/add_account", methods=["POST"])
def add_account():
    data = request.json or {}
    uid = data.get("uid")
    password = data.get("pass")
    twofa = data.get("twofa")
    proxy = data.get("proxy", "")
    datr = (data.get("datr") or "").strip()
    try:
        fb = facebook_login(
            uid_phone_mail=uid, password=password,
            twofactor_code=twofa, proxies=parse_proxy(proxy), datr=datr,
        )
        result = fb.login()
        if result["success"]:
            fb_name = get_fb_name(result["original_token"]["access_token"], parse_proxy(proxy))
            if (not fb_name) or ("lỗi" in fb_name.lower()) or ("không lấy" in fb_name.lower()) or ("token" in fb_name.lower()):
                fb_name = result["cookies"]["dict"].get("c_user", uid)
            result["fb_name"] = fb_name
            result["fb_uid"] = result["cookies"]["dict"].get("c_user", "Unknown")
            result["proxy"] = proxy
            result["status"] = "✅ Live"
            result["is_alive"] = True
            result["password"] = password
            return jsonify({"success": True, "data": result})
        return jsonify({"success": False, "error": result["error"]})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/api/check_proxy", methods=["POST"])
def api_check_proxy():
    proxies = parse_proxy((request.json or {}).get("proxy"))
    if not proxies:
        return jsonify({"success": False, "error": "❌ Proxy rỗng"})
    try:
        r = requests.get("https://api.ipify.org?format=json", proxies=proxies, timeout=10)
        if r.status_code == 200:
            return jsonify({"success": True, "ip": r.json().get("ip")})
        return jsonify({"success": False, "error": "Lỗi kết nối"})
    except Exception:
        return jsonify({"success": False, "error": "❌ Proxy Die hoặc lỗi kết nối"})

@app.route("/api/get_logs", methods=["POST"])
def api_get_logs():
    return jsonify({"logs": bot_logs.get((request.json or {}).get("id"), [])})

@app.route("/api/toggle_bot", methods=["POST"])
def toggle_bot():
    data = request.json or {}
    acc_id = data.get("id")
    token_data = data.get("token_data")
    if not token_data:
        return jsonify({"success": False, "error": "Dữ liệu không hợp lệ."})

    with _bot_lock:
        if running_bots.get(acc_id):
            running_bots[acc_id] = False
            if acc_id in bot_logs:
                bot_logs[acc_id].append("[<☆>] Đã dừng nuôi acc.")
            return jsonify({"success": True, "is_running": False})
        running_bots[acc_id] = True
        bot_logs[acc_id] = ["[<☆>] Bắt đầu nuôi acc..."]

    token_eaaa = token_data["original_token"]["access_token"]
    cookie_dict = token_data["cookies"]["dict"]
    uid = cookie_dict.get("c_user", "0")
    proxies = parse_proxy(token_data.get("proxy", ""))

    def add_log(msg, is_error=False, is_success=False, is_warning=False, is_raw=False):
        if acc_id not in bot_logs:
            bot_logs[acc_id] = []
        if is_error:
            msg = f"<span style='color:#FF4D4F'>{msg}</span>"
        elif is_success:
            msg = f"<span style='color:#2DC988'>{msg}</span>"
        elif is_warning:
            msg = f"<span style='color:#F5A623'>{msg}</span>"
        elif is_raw:
            msg = f"<span style='color:#829AFF;font-style:italic;'>{msg}</span>"
        if is_raw and not SHOW_RAW_RESPONSE:
            return
        bot_logs[acc_id].append(msg)
        if len(bot_logs[acc_id]) > 50:
            bot_logs[acc_id].pop(0)

    def sleep_with_countdown(seconds, message=""):
        m, s = divmod(int(seconds), 60)
        base_msg = message if message else "[<ⴵ>] Đang chờ..."
        add_log(f"{base_msg} (Còn lại: {m:02d}:{s:02d})")
        for i in range(int(seconds) - 1, -1, -1):
            if not running_bots.get(acc_id):
                break
            time.sleep(1)
            m, s = divmod(i, 60)
            if bot_logs.get(acc_id):
                bot_logs[acc_id][-1] = f"{base_msg} (Còn lại: {m:02d}:{s:02d})"

    def run_bot():
        session = tao_phien(cookie_dict, CHROME_UA, proxies)
        meta = lay_metadata(session, proxies)
        fb_dtsg, lsd = meta.get("fb_dtsg"), meta.get("lsd")
        if not fb_dtsg:
            add_log("[<❌>] Lỗi: Không lấy được fb_dtsg. Kiểm tra cookie/proxy.", is_error=True)
            running_bots[acc_id] = False
            return
        jazoest = "2" + "".join(str(ord(c)) for c in fb_dtsg)
        ai = facebook_ai(MISTRAL_API_KEY)
        session_count = 0
        last_post_session = -96

        while running_bots.get(acc_id):
            try:
                alive_session = check_alive_by_session(session, proxies)
                alive_token = check_live_die(token_eaaa, proxies)
                # Chỉ báo DIE khi CẢ HAI đều chắc chắn chết
                if alive_session is False and alive_token is False:
                    acc_name = token_data.get("fb_name", "Không rõ tên")
                    add_log("[<❌>] Tài khoản đã bị DIE (Checkpoint/Khóa)! Dừng nuôi acc.", is_error=True)
                    running_bots[acc_id] = False
                    bot_logs[acc_id].append("DIE_ALERT:" + acc_name)
                    save_notification(
                        "ACC DIE RỒI!",
                        f"ACC {acc_name} CỦA BẠN DIE MẤT TIÊU ÒI HUHU, XIN LỖI VÌ SỰ ĐÁNG TIẾT NÀYY=(((",
                    )
                    break
                if alive_session is False and alive_token is True:
                    add_log("[<⚠️>] Cookie web có vẻ chết nhưng token còn. Thử refresh metadata...", is_warning=True)
                if alive_session is True and alive_token is False:
                    add_log("[<⚠️>] Token EAAAAU chết nhưng cookie web còn. Chỉ dùng web actions.", is_warning=True)

                session_count += 1
                can_post = (session_count - last_post_session) >= 96

                if can_post and alive_token is not False:
                    add_log("[<ⴵ>] Đang đăng bài...")
                    chu_de = random.choice([
                        "tâm trạng", "tình yêu", "cuộc sống", "sự mệt mỏi", "niềm vui",
                        "nỗi buồn", "sự cô đơn", "gia đình", "tình bạn", "ước mơ",
                        "hoài niệm", "sự trưởng thành", "lòng biết ơn", "sự tha thứ",
                        "nỗi nhớ", "sự bình yên", "động lực", "thất bại", "sự thay đổi",
                        "hy vọng", "triết lý sống", "sự chữa lành", "lòng tự trọng",
                        "sự kiên nhẫn", "hạnh phúc giản đơn",
                    ])
                    noi_dung = ai.tao_bai_dang(chu_de, proxies)
                    if noi_dung:
                        post_id = graph_dang_bai(noi_dung, token_eaaa, proxies)
                        if post_id and not str(post_id).startswith("ERROR") and not str(post_id).startswith("EXCEPTION"):
                            post_link = f"https://www.facebook.com/{uid}/posts/{post_id.split('_')[-1]}"
                            add_log(f"[<✅>] Đăng bài thành công. Link: {post_link}", is_success=True)
                            last_post_session = session_count
                        else:
                            add_log(f"[<❌>] Đăng bài thất bại! Chi tiết: {post_id}", is_error=True)
                    sleep_with_countdown(random.uniform(120, 180), "[<ⴵ>] Nghỉ ngơi sau khi đăng bài...")

                posts = get_feed_posts(session, uid, fb_dtsg, jazoest, lsd, proxies)
                if isinstance(posts, tuple):
                    real_posts, raw_log = posts
                    add_log(raw_log, is_raw=True)
                    posts = real_posts
                if isinstance(posts, str):
                    add_log(f"[<❌>] Quét Feed thất bại! {posts}", is_error=True)
                elif posts:
                    so_lan_tuong_tac = random.randint(5, 7)
                    selected_posts = random.sample(posts, min(len(posts), so_lan_tuong_tac))
                    for idx, (pid, msg, author_id) in enumerate(selected_posts):
                        if not running_bots.get(acc_id):
                            break
                        full_pid = _build_full_post_id(pid, author_id)
                        total_wait = random.uniform(10, 15) + random.uniform(2, 4)
                        sleep_with_countdown(total_wait, f"[<ⴵ>] Chuẩn bị tương tác bài: {pid}")
                        reaction, comment, raw_resp = ai.phan_tich_bai_viet(msg, proxies)
                        add_log(f"[AI Raw] {raw_resp}", is_raw=True)

                        if alive_token is not False:
                            res_rx = graph_tha_cam_xuc(full_pid, reaction, token_eaaa, proxies)
                            if res_rx is not True:
                                if "Unsupported post request" in str(res_rx):
                                    add_log(f"[<⚠️>] Bỏ qua bài {pid} (Bị chặn quyền tương tác).", is_warning=True)
                                else:
                                    add_log(f"[<❌>] Lỗi thả cảm xúc bài {pid}! {res_rx}", is_error=True)
                                    add_log(f"[GraphQL Reaction Raw] {res_rx}", is_raw=True)
                            res_cmt = graph_comment(full_pid, comment, token_eaaa, proxies)
                            if res_cmt is not True:
                                if "Unsupported post request" not in str(res_cmt):
                                    add_log(f"[<❌>] Lỗi bình luận bài {pid}! {res_cmt}", is_error=True)
                                    add_log(f"[GraphQL Comment Raw] {res_cmt}", is_raw=True)
                            if res_rx is True and res_cmt is True:
                                post_link = format_post_link(pid, uid, author_id)
                                add_log(f"[<✅>] Tương tác thành công. Link: {post_link}", is_success=True)
                        else:
                            add_log(f"[<⚠️>] Token chết, bỏ qua tương tác bài {pid}.", is_warning=True)

                        # Xen kẽ kết bạn
                        if idx == len(selected_posts) // 2:
                            add_log("[<ⴵ>] Bắt đầu kết bạn (xen kẽ)...")
                            suggested_uids = get_suggested_friends(session, uid, fb_dtsg, jazoest, lsd, proxies)
                            if suggested_uids:
                                targets = random.sample(suggested_uids, min(len(suggested_uids), 2))
                                add_log(f"[<✅>] Đã tìm thấy {len(suggested_uids)} gợi ý. Sẽ kết bạn với {len(targets)} người...", is_success=True)
                                for target_id in targets:
                                    if not running_bots.get(acc_id):
                                        break
                                    sleep_with_countdown(random.uniform(30, 60), "[<ⴵ>] Chuẩn bị gửi lời mời kết bạn...")
                                    res_fr = graphql_ket_ban(session, uid, fb_dtsg, jazoest, lsd, target_id, proxies)
                                    if res_fr is True:
                                        add_log(f"[<✅>] Đã gửi lời mời kết bạn tới ID: {target_id}", is_success=True)
                                    else:
                                        add_log(f"[<❌>] Gửi lời mời kết bạn thất bại cho ID {target_id}. Chi tiết: {res_fr}", is_error=True)
                                        add_log(f"[GraphQL Friend Raw] {res_fr}", is_raw=True)
                            else:
                                add_log("[<❌>] Không lấy được danh sách gợi ý kết bạn.", is_error=True)

                        sleep_with_countdown(random.uniform(240, 300), "[<ⴵ>] Nghỉ ngơi giữa các bài viết...")
                sleep_with_countdown(300, f"[<ⴵ>] Kết thúc phiên {session_count}. Nghỉ ngơi...")
            except Exception as e:
                add_log(f"[<❌>] Lỗi hệ thống nghiêm trọng: {e}", is_error=True)
                sleep_with_countdown(60, "[<ⴵ>] Đang thử phục hồi sau lỗi...")

    threading.Thread(target=run_bot, daemon=True).start()
    return jsonify({"success": True, "message": "Đã bắt đầu Bot", "is_running": True})

@app.route("/api/thongbaohethong", methods=["GET", "POST"])
def api_thongbaohethong():
    if request.is_json:
        data = request.get_json(silent=True) or {}
    else:
        data = request.args.to_dict()
    title = data.get("title", "Thông báo hệ thống")
    content = data.get("content", "Nội dung thông báo")
    save_notification(title, content)
    return jsonify({"success": True, "message": "Đã lưu thông báo", "title": title, "content": content})

@app.route("/")
def index():
    for p in ["index.html", "assets/index.html", os.path.join(os.path.dirname(__file__), "index.html")]:
        if os.path.exists(p):
            return send_from_directory(
                os.path.dirname(p) if os.path.dirname(p) else ".",
                os.path.basename(p),
            )
    return "[<❌>] Lỗi: Không tìm thấy giao diện!", 404

def run_server():
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8080"))
    t = threading.Thread(
        target=lambda: app.run(host=host, port=port, threaded=True, use_reloader=False, debug=False),
        daemon=True,
    )
    t.start()
    import socket
    for _ in range(50):
        try:
            s = socket.create_connection(("127.0.0.1", port), timeout=0.1)
            s.close()
            return
        except Exception:
            time.sleep(0.1)

if __name__ == "__main__":
    run_server()