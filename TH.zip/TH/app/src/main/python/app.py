import random
import string
import json
import time
import uuid
import base64
import io
import struct
import re
import os
import threading
import requests
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from Crypto.Cipher import AES, PKCS1_v1_5
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__, static_folder=".")
CORS(app)

def get_safe_android_path():
    target_paths = ["/storage/emulated/0/Download/SnowPanel_Data", "/sdcard/Download/SnowPanel_Data", "/storage/emulated/0/Documents/SnowPanel_Data", "/sdcard/Documents/SnowPanel_Data"]
    for path in target_paths:
        try:
            os.makedirs(path, exist_ok=True)
            test_file = os.path.join(path, ".test")
            with open(test_file, "w") as f: f.write("1")
            os.remove(test_file)
            return path
        except: continue
    return os.path.dirname(os.path.abspath(__file__))

BASE_DIR = get_safe_android_path()
DEVICE_POOL_FILE = os.path.join(BASE_DIR, "device_pool.json")

running_bots = {}
bot_logs = {}
SHOW_RAW_RESPONSE = False 
TIMEOUT = 20
MISTRAL_API_KEY = "mstrl_N4uIpAyBTp3TNxDOPdLAfp64R1Sl9UVx_3DK7oj"
MISTRAL_API_URL = "https://api.mistral.ai/v1/chat/completions"
MODEL_AI = "mistral-tiny"

def load_device_pool():
    if os.path.exists(DEVICE_POOL_FILE):
        try:
            with open(DEVICE_POOL_FILE, "r", encoding="utf-8") as f: return json.load(f)
        except: return {}
    return {}

def save_device_pool(data):
    try:
        with open(DEVICE_POOL_FILE, "w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False, indent=2)
    except: pass

def get_pinned_device(email, datr=None):
    pool = load_device_pool()
    if email in pool and not datr: return pool[email]
    device = pool.get(email, {
        "device_id": str(uuid.uuid4()), "adid": str(uuid.uuid4()), "secure_family_device_id": str(uuid.uuid4()),
        "jazoest": "".join(random.choices(string.digits, k=5)), "sim_serial": "".join(random.choices(string.digits, k=20)),
        "user_agent": "Dalvik/2.1.0 (Linux; U; Android 9; 23113RKC6C Build/PQ3A.190705.08211809) [FBAN/FB4A;FBAV/417.0.0.33.65;FBPN/com.facebook.katana;FBLC/vi_VN;FBBV/480086274;FBCR/MobiFone;FBMF/Redmi;FBBD/Redmi;FBDV/23113RKC6C;FBSV/9;FBCA/x86:armeabi-v7a;FBDM/{density=1.5,width=1280,height=720};FB_FW/1;FBRV/0;]",
        "last_login": time.time(),
    })
    if datr: device["machine_id"] = datr
    elif "machine_id" not in device: device["machine_id"] = "".join(random.choices(string.ascii_letters + string.digits, k=24))
    pool[email] = device
    save_device_pool(pool)
    return device

def parse_proxy(proxy_str):
    if not proxy_str or proxy_str.strip() == "": return None
    p = proxy_str.strip()
    if "://" in p: return {"http": p, "https": p}
    parts = p.split(":")
    if len(parts) == 4: return {"http": f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}", "https": f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"}
    elif len(parts) == 2: return {"http": f"http://{parts[0]}:{parts[1]}", "https": f"http://{parts[0]}:{parts[1]}"}
    return {"http": f"http://{p}", "https": f"http://{p}"}

def get_fb_name(token, proxies=None):
    try:
        res = requests.get("https://graph.facebook.com/v18.0/me", params={"fields": "id,name", "access_token": token}, proxies=proxies, timeout=10)
        if res.status_code == 200: return res.json().get("name", "❌ Không lấy được tên")
        return "❌ Token lỗi"
    except: return "❌ Lỗi mạng"

def check_live_die(token, proxies=None):
    try:
        res = requests.get("https://graph.facebook.com/v18.0/me", params={"access_token": token}, proxies=proxies, timeout=10)
        if res.status_code == 200: return True
        elif res.status_code in [400, 401, 403]: return False
        return True 
    except:
        return True 

class facebook_password_encryptor:
    @staticmethod
    def get_public_key(proxies=None):
        try:
            url = "https://b-graph.facebook.com/pwd_key_fetch"
            params = {"version": "2", "flow": "CONTROLLER_INITIALIZATION", "method": "GET", "fb_api_req_friendly_name": "pwdKeyFetch", "fb_api_caller_class": "com.facebook.auth.login.AuthOperations", "access_token": "438142079694454|fc0a7caa49b192f64f6f5a6d9643bb28"}
            res = requests.post(url, params=params, proxies=proxies, timeout=TIMEOUT).json()
            return res.get("public_key"), str(res.get("key_id", "25"))
        except: return None, "25"
    @staticmethod
    def encrypt(password, public_key=None, key_id="25", proxies=None):
        if public_key is None: public_key, key_id = facebook_password_encryptor.get_public_key(proxies)
        if not public_key: return password
        try:
            rand_key = get_random_bytes(32); iv = get_random_bytes(12); pubkey = RSA.import_key(public_key)
            cipher_rsa = PKCS1_v1_5.new(pubkey); encrypted_rand_key = cipher_rsa.encrypt(rand_key)
            cipher_aes = AES.new(rand_key, AES.MODE_GCM, nonce=iv); current_time = int(time.time())
            cipher_aes.update(str(current_time).encode("utf-8"))
            encrypted_passwd, auth_tag = cipher_aes.encrypt_and_digest(password.encode("utf-8"))
            buf = io.BytesIO(); buf.write(bytes([1, int(key_id)])); buf.write(iv); buf.write(struct.pack("<h", len(encrypted_rand_key)))
            buf.write(encrypted_rand_key); buf.write(auth_tag); buf.write(encrypted_passwd)
            return f"#PWD_FB4A:2:{current_time}:{base64.b64encode(buf.getvalue()).decode('utf-8')}"
        except: return password

class FacebookAppTokens:
    APPS = {"FB_ANDROID": {"app_id": "350685531728"}, "MESSENGER_ANDROID": {"app_id": "256002347743983"}, "FB_LITE": {"app_id": "275254692598279"}, "MESSENGER_LITE": {"app_id": "200424423651082"}, "ADS_MANAGER_ANDROID": {"app_id": "438142079694454"}, "PAGES_MANAGER_ANDROID": {"app_id": "121876164619130"}}
    @staticmethod
    def get_app_id(app_key): return FacebookAppTokens.APPS.get(app_key, {}).get("app_id")
    @staticmethod
    def get_all_app_keys(): return list(FacebookAppTokens.APPS.keys())
    @staticmethod
    def extract_token_prefix(token):
        for i, char in enumerate(token):
            if char.islower(): return token[:i]
        return token

class facebook_login:
    API_URL = "https://b-graph.facebook.com/auth/login"
    ACCESS_TOKEN = "350685531728|62f8ce9f74b12f84c123cc23437a4a32"
    API_KEY = "882a8490361da98702bf97a021ddc14d"
    SIG = "214049b9f17c38bd767de53752b53946"
    BASE_HEADERS = {"content-type": "application/x-www-form-urlencoded", "x-fb-net-hni": "45201", "zero-rated": "0", "x-fb-sim-hni": "45201", "x-fb-connection-quality": "EXCELLENT", "x-fb-friendly-name": "authenticate", "x-fb-connection-bandwidth": "78032897", "x-tigon-is-retry": "False", "authorization": "OAuth null", "x-fb-connection-type": "WIFI", "x-fb-device-group": "3342", "priority": "u=3,i", "x-fb-http-engine": "Liger", "x-fb-client-ip": "True", "x-fb-server-cluster": "True"}

    def __init__(self, uid_phone_mail, password, twofactor_code=None, proxies=None, datr=None):
        self.uid_phone_mail = uid_phone_mail; self.twofactor_code = twofactor_code; self.proxies = proxies
        pinned = get_pinned_device(uid_phone_mail, datr)
        self.machine_id = pinned["machine_id"]; self.device_id = pinned["device_id"]
        self.adid = pinned["adid"]; self.secure_family_device_id = pinned["secure_family_device_id"]
        self.jazoest = pinned["jazoest"]; self.sim_serial = pinned["sim_serial"]; self.user_agent = pinned["user_agent"]
        self.password = password if password.startswith("#PWD_FB4A") else facebook_password_encryptor.encrypt(password, proxies=proxies)
        self.session = requests.Session()
        if self.proxies: self.session.proxies.update(self.proxies)
        self.headers = self._build_headers(); self.data = self._build_data()

    def _build_headers(self):
        headers = self.BASE_HEADERS.copy()
        headers.update({"x-fb-request-analytics-tags": '{"network_tags":{"product":"350685531728","retry_attempt":"0"},"application_tags":"unknown"}', "user-agent": self.user_agent})
        return headers

    def _build_data(self):
        return {"format": "json", "email": self.uid_phone_mail, "password": self.password, "credentials_type": "password", "generate_session_cookies": "1", "api_key": self.API_KEY, "access_token": self.ACCESS_TOKEN, "adid": self.adid, "device_id": self.device_id, "generate_analytics_claim": "1", "community_id": "", "linked_guest_account_userid": "", "cpl": "true", "try_num": "1", "family_device_id": self.device_id, "secure_family_device_id": self.secure_family_device_id, "sim_serials": f'["{self.sim_serial}"]', "openid_flow": "android_login", "openid_provider": "google", "openid_tokens": "[]", "account_switcher_uids": f'["{self.uid_phone_mail}"]', "fb4a_shared_phone_cpl_experiment": "fb4a_shared_phone_nonce_cpl_at_risk_v3", "fb4a_shared_phone_cpl_group": "enable_v3_at_risk", "enroll_misauth": "false", "error_detail_type": "button_with_disabled", "source": "login", "machine_id": self.machine_id, "jazoest": self.jazoest, "meta_inf_fbmeta": "V2_UNTAGGED", "advertiser_id": self.adid, "encrypted_msisdn": "", "currently_logged_in_userid": "0", "fb_api_req_friendly_name": "authenticate", "fb_api_caller_class": "Fb4aAuthHandler", "sig": self.SIG}

    def _convert_token(self, access_token, target_app):
        try:
            app_id = FacebookAppTokens.get_app_id(target_app)
            if not app_id: return None
            response = requests.post("https://api.facebook.com/method/auth.getSessionforApp", data={"access_token": access_token, "format": "json", "new_app_id": app_id, "generate_session_cookies": "1"}, proxies=self.proxies, timeout=15)
            result = response.json()
            if "access_token" in result:
                token = result["access_token"]; prefix = FacebookAppTokens.extract_token_prefix(token)
                cookies_dict, cookies_string = {}, ""
                if "session_cookies" in result:
                    for cookie in result["session_cookies"]:
                        cookies_dict[cookie["name"]] = cookie["value"]; cookies_string += f"{cookie['name']}={cookie['value']}; "
                return {"token_prefix": prefix, "access_token": token, "cookies": {"dict": cookies_dict, "string": cookies_string.rstrip("; ")}}
            return None
        except: return None

    def _parse_success(self, res_json):
        c_dict, c_str = {}, ""
        if "session_cookies" in res_json:
            for c in res_json["session_cookies"]:
                c_dict[c["name"]] = c["value"]; c_str += f"{c['name']}={c['value']}; "
        original_token = res_json["access_token"]
        result = {"success": True, "original_token": {"token_prefix": FacebookAppTokens.extract_token_prefix(original_token), "access_token": original_token}, "cookies": {"dict": c_dict, "string": c_str.rstrip("; ")}, "user_agent": self.user_agent}
        result["converted_tokens"] = {}
        for target_app in FacebookAppTokens.get_all_app_keys():
            converted = self._convert_token(original_token, target_app)
            if converted: result["converted_tokens"][target_app] = converted
        return result

    def _handle_2fa(self, error_data):
        if not self.twofactor_code: return {"success": False, "error": "❌ Yêu cầu 2FA nhưng chưa nhập mã."}
        data_2fa = self._build_data()
        data_2fa.update({"credentials_type": "two_factor", "twofactor_code": self.twofactor_code, "first_factor": error_data.get("login_first_factor"), "userid": error_data.get("uid")})
        try:
            res = self.session.post(self.API_URL, headers=self.headers, data=data_2fa, proxies=self.proxies, timeout=TIMEOUT).json()
            if "access_token" in res: return self._parse_success(res)
            return {"success": False, "error": res.get("error", {}).get("message", "❌ Mã 2FA sai")}
        except Exception as e: return {"success": False, "error": f"Lỗi 2FA: {e}"}

    def login(self):
        try:
            if self.proxies:
                try: requests.get("https://api.ipify.org", proxies=self.proxies, timeout=10)
                except: return {"success": False, "error": "Proxy không phản hồi (Timeout)"}
            try: response = self.session.post(self.API_URL, headers=self.headers, data=self.data, proxies=self.proxies, timeout=TIMEOUT)
            except requests.exceptions.Timeout: return {"success": False, "error": "❌ Facebook không phản hồi (Timeout)"}
            except requests.exceptions.ProxyError: return {"success": False, "error": "❌ Facebook chặn Proxy"}
            except Exception as e: return {"success": False, "error": f"❌ Lỗi mạng: {str(e)}"}

            response_json = response.json()
            if "access_token" in response_json:
                if not response_json["access_token"].startswith("EAAA"): return {"success": False, "error": "Token không phải EAAA"}
                return self._parse_success(response_json)
            if "error" in response_json:
                err_data = response_json["error"].get("error_data", {})
                if "login_first_factor" in err_data and "uid" in err_data: return self._handle_2fa(err_data)
                err_msg = response_json["error"].get("message", "❌ Lỗi không xác định")
                if "abusive" in err_msg.lower(): return {"success": False, "error": "❌❌ ACC BỊ DÍNH SPAM LOGIN (ABUSIVE). VUI LÒNG NGÂM ACC TRONG 3 NGÀY HOẶC DÙNG 'datr' ĐỂ LOGIN!"}
                return {"success": False, "error": err_msg}
            return {"success": False, "error": "❌ Sai định dạng phản hồi"}
        except Exception as e: return {"success": False, "error": f"❌ Lỗi Python: {str(e)}"}

def tao_phien(c_dict, user_agent, proxies=None):
    s = requests.Session()
    s.headers.update({"User-Agent": user_agent, "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8", "Accept-Language": "en-US,en;q=0.9"})
    for k, v in c_dict.items(): s.cookies.set(k, v, domain=".facebook.com")
    if proxies: s.proxies.update(proxies)
    return s

def lay_metadata(s, proxies=None):
    meta = {"fb_dtsg": None, "lsd": None}
    try:
        r = s.get("https://www.facebook.com/", timeout=TIMEOUT, proxies=proxies)
        m = re.search(r'"DTSGInitialData":\{"token":"(.*?)"', r.text) or re.search(r'\["DTSGInitialData",\[\],\{"token":"(.*?)"\}', r.text)
        if m: meta["fb_dtsg"] = m.group(1)
        m = re.search(r'"LSD":\{"token":"(.*?)"', r.text) or re.search(r'\["LSD",\[\],\{"token":"(.*?)"\}', r.text)
        if m: meta["lsd"] = m.group(1)
    except: pass
    if not meta["fb_dtsg"]:
        try:
            r = s.get("https://business.facebook.com/", timeout=TIMEOUT, proxies=proxies)
            m = re.search(r'name="fb_dtsg" value="([^"]+)"', r.text) or re.search(r'"DTSGInitialData",\[\],\{"token":"([^"]+)"', r.text)
            if m: meta["fb_dtsg"] = m.group(1)
        except: pass
    return meta

class facebook_ai:
    def __init__(self, api_key):
        self.api_key = api_key; self.model = MODEL_AI
    def _goi_ai(self, prompt, proxies=None):
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {"model": self.model, "messages": [{"role": "user", "content": prompt}], "temperature": 0.9, "max_tokens": 200}
        for attempt in range(3):
            try:
                res = requests.post(MISTRAL_API_URL, headers=headers, json=payload, timeout=20, proxies=proxies)
                if res.status_code == 200: return res.json()["choices"][0]["message"]["content"].strip()
                elif res.status_code == 429: time.sleep(15)
                else: break
            except: time.sleep(5)
        return None
        
    def phan_tich_bai_viet(self, text, proxies=None):
        if not text or len(text) < 10: return "LOVE", "Hay quá!", "Text ngắn"
        prompt = f"""
        Bạn là một người dùng Facebook GenZ thực thụ, nói chuyện tự nhiên, có thể viết tắt (teencode) nhẹ và dùng icon chính xác với ngữ cảnh.
        Bài viết vừa đọc: "{text}"
        Nhiệm vụ:
        1. Chọn 1 cảm xúc phù hợp (chỉ được chọn: LIKE, LOVE, HAHA, WOW, SAD, ANGRY - BẮT BUỘC VIẾT HOA).
        2. Viết 1 câu bình luận ngắn (dưới 15 chữ).
        
        YÊU CẦU BẮT BUỘC: Bạn CHỈ ĐƯỢC PHÉP trả về chuỗi JSON theo đúng mẫu dưới đây. Tuyệt đối không thêm bất kỳ lời giải thích nào khác, không dùng markdown.
        Mẫu chuẩn: {{"reaction": "CẢM_XÚC_VIẾT_HOA", "comment": "NỘI_DUNG"}}
        """
        ket_qua = self._goi_ai(prompt, proxies)
        raw_resp = ket_qua if ket_qua else "Lỗi gọi API AI"
        
        if ket_qua:
            try:
                match = re.search(r'\{.*?\}', ket_qua.replace('\n', ' '), re.IGNORECASE)
                if match:
                    json_str = match.group(0)
                    data = json.loads(json_str)
                    if "reaction" in data and "comment" in data:
                        return str(data["reaction"]).upper(), str(data["comment"]), raw_resp
            except: pass
        return "LIKE", "Hay quá bạn ơi! ❤️", raw_resp

    def tao_bai_dang(self, chu_de, proxies=None):
        prompt = f"""
        Bạn là một người dùng Facebook GenZ Việt Nam.
        Viết bài đăng Facebook về chủ đề: "{chu_de}".
        Yêu cầu: 3-5 câu, phong cách GenZ, tình cảm, tự nhiên, có thể dùng teencode. Thêm icon chính xác.
        TUYỆT ĐỐI KHÔNG dùng định dạng Markdown (không dùng dấu **, không dùng #).
        BÀI VIẾT DÀI CÙNG LẮM LÀ 3 DÒNG THÔI
        QUY TẮC ĐẶT HASHTAG (BẮT BUỘC TUÂN THỦ):
        - TUYỆT ĐỐI KHÔNG tự bịa ra bất kỳ hashtag nào khác.
        - Dòng cuối cùng của bài viết BẮT BUỘC phải là dòng này (không được viết hoa, không thêm bớt): #teungheui_bot09
        """
        ket_qua = self._goi_ai(prompt, proxies)
        return ket_qua if ket_qua else f"Hôm nay thật tuyệt! #teungheui_bot09"

def get_feed_posts(session, uid, fb_dtsg, jazoest, lsd, proxies=None):
    url = "https://www.facebook.com/api/graphql/"
    headers = {"content-type": "application/x-www-form-urlencoded", "x-fb-friendly-name": "CometNewsFeedPaginationQuery", "x-fb-lsd": lsd if lsd else "", "origin": "https://www.facebook.com", "referer": "https://www.facebook.com/"}
    variables = {"RELAY_INCREMENTAL_DELIVERY": True, "clientQueryId": str(uuid.uuid4()), "clientSession": None, "connectionClass": "GOOD", "count": 10, "cursor": None, "experimentalValues": None, "feedLocation": "NEWSFEED", "feedStyle": "DEFAULT", "feedbackSource": 1, "focusCommentID": None, "orderby": ["TOP_STORIES"], "privacySelectorRenderLocation": "COMET_STREAM", "recentVPVs": [], "referringStoryRenderLocation": None, "refreshMode": "AUTO", "renderLocation": "homepage_stream", "scale": 3, "shouldChangeBRSLabelFieldName": False, "shouldObfuscateCategoryField": True, "shouldUseBRSLabelFieldNameV1": False, "shouldUseBRSLabelFieldNameV2": False, "useDefaultActor": False, "__relay_internal__pv__GHLShouldChangeSponsoredAuctionDistanceFieldNamerelayprovider": True, "__relay_internal__pv__GHLShouldUseSponsoredAuctionLabelFieldNameV1relayprovider": True, "__relay_internal__pv__GHLShouldUseSponsoredAuctionLabelFieldNameV2relayprovider": False, "__relay_internal__pv__GHLShouldChangeSponsoredDataFieldNamerelayprovider": True, "__relay_internal__pv__GHLShouldChangeAdIdFieldNamerelayprovider": True, "__relay_internal__pv__CometAdsSlotFillLoggingEnabledrelayprovider": False, "__relay_internal__pv__CometFeedStory_enable_reactor_facepilerelayprovider": False, "__relay_internal__pv__CometFeedStory_enable_social_bubblesrelayprovider": False, "__relay_internal__pv__CometFeedStory_enable_post_permalink_white_space_clickrelayprovider": False, "__relay_internal__pv__CometUFICommentActionLinksRewriteEnabledrelayprovider": True, "__relay_internal__pv__IsWorkUserrelayprovider": False, "__relay_internal__pv__CometUFICommentAvatarStickerAnimatedImagerelayprovider": False, "__relay_internal__pv__TestPilotShouldIncludeDemoAdUseCaserelayprovider": False, "__relay_internal__pv__FBReels_deprecate_short_form_video_context_gkrelayprovider": True, "__relay_internal__pv__CometUFI_dedicated_comment_routable_dialog_gkrelayprovider": True, "__relay_internal__pv__FBReels_enable_view_dubbed_audio_type_gkrelayprovider": True, "__relay_internal__pv__CometFeedShareMedia_shouldPrefetchShareImagerelayprovider": False, "__relay_internal__pv__CometImmersivePhotoCanUserDisable3DMotionrelayprovider": False, "__relay_internal__pv__WorkCometIsEmployeeGKProviderrelayprovider": False, "__relay_internal__pv__IsMergQAPollsrelayprovider": False, "__relay_internal__pv__FBReelsMediaFooter_comet_enable_reels_ads_gkrelayprovider": True, "__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider": False, "__relay_internal__pv__CometUFICommentAutoTranslationTyperelayprovider": "AUTO_TRANSLATE", "__relay_internal__pv__CometUFIShareActionMigrationrelayprovider": True, "__relay_internal__pv__CometUFISingleLineUFIrelayprovider": True, "__relay_internal__pv__relay_provider_comet_ufi_ssr_seo_deferrelayprovider": True, "__relay_internal__pv__FBReelsIFUTileContent_reelsIFUPlayOnHoverrelayprovider": True, "__relay_internal__pv__GroupsCometGYSJFeedItemHeightrelayprovider": 206, "__relay_internal__pv__StoriesShouldEnablePhotosensitiveContentWarningrelayprovider": False, "__relay_internal__pv__ShouldEnableBakedInTextStoriesrelayprovider": False, "__relay_internal__pv__StoriesShouldIncludeFbNotesrelayprovider": True}
    data = {"av": uid, "fb_dtsg": fb_dtsg, "jazoest": jazoest, "lsd": lsd, "__user": uid, "__a": "1", "fb_api_caller_class": "RelayModern", "fb_api_req_friendly_name": "CometNewsFeedPaginationQuery", "variables": json.dumps(variables, separators=(",", ":")), "doc_id": "39846308615014480", "server_timestamps": "true"}
    try:
        res = session.post(url, headers=headers, data=data, timeout=TIMEOUT, proxies=proxies)
        raw_text = res.text
        posts = []
        for line in raw_text.splitlines():
            try: obj = json.loads(line)
            except: continue
            def extract(o):
                if isinstance(o, dict):
                    if "post_id" in o and isinstance(o["post_id"], str):
                        msg = ""
                        author_id = ""
                        if isinstance(o.get("message"), dict) and "text" in o["message"]: msg = o["message"]["text"]
                        if isinstance(o.get("actors"), list) and len(o["actors"]) > 0:
                            author_id = str(o["actors"][0].get("id", ""))
                        posts.append((o["post_id"], msg, author_id))
                    for v in o.values(): extract(v)
                elif isinstance(o, list):
                    for i in o: extract(i)
            extract(obj)
            
        unique_posts = []
        seen = set()
        for pid, msg, author_id in posts:
            if pid not in seen:
                seen.add(pid)
                if author_id != uid: unique_posts.append((pid, msg, author_id))
                    
        if SHOW_RAW_RESPONSE:
            preview = raw_text[:300].replace('\n', ' ')
            return unique_posts, f"RAW FEED: {preview}..."
                
        if not unique_posts: return "ERROR_RESPONSE: " + raw_text[:500]
        return unique_posts
    except Exception as e: return "ERROR_EXCEPTION: " + str(e)

def format_post_link(pid, uid, author_id=None):
    if author_id == uid: return f"https://www.facebook.com/{uid}"
    if "_" in pid:
        parts = pid.split("_")
        return f"https://www.facebook.com/{parts[0]}/posts/{parts[1]}"
    else:
        return f"https://www.facebook.com/{uid}/posts/{pid}"

def graph_dang_bai(caption_text, token, proxies=None):
    try:
        res = requests.post("https://graph.facebook.com/v26.0/me/feed", data={"message": caption_text, "access_token": token, "privacy": '{"value":"EVERYONE"}'}, timeout=TIMEOUT, proxies=proxies)
        js = res.json()
        if "id" in js: return js["id"]
        return "ERROR: " + str(js.get("error", {}).get("message", "Unknown"))
    except Exception as e: return "EXCEPTION: " + str(e)

def graph_tha_cam_xuc(full_post_id, reaction_type, token, proxies=None):
    try:
        res = requests.post(f"https://graph.facebook.com/v26.0/{full_post_id}/reactions", data={"type": reaction_type, "access_token": token}, timeout=TIMEOUT, proxies=proxies)
        if res.status_code == 200: return True
        return "Lỗi FB: " + res.text[:100]
    except Exception as e: return "Lỗi mạng: " + str(e)

def graph_comment(full_post_id, message, token, proxies=None):
    try:
        res = requests.post(f"https://graph.facebook.com/v26.0/{full_post_id}/comments", data={"message": message, "access_token": token}, timeout=TIMEOUT, proxies=proxies)
        if res.status_code == 200: return True
        return "Lỗi FB: " + res.text[:100]
    except Exception as e: return "Lỗi mạng: " + str(e)

def graph_ket_ban(uid_target, token, proxies=None):
    try:
        res = requests.post(f"https://graph.facebook.com/v26.0/{uid_target}/friends", data={"access_token": token}, timeout=TIMEOUT, proxies=proxies)
        if res.status_code == 200: return True
        return "Lỗi FB: " + res.text[:100]
    except Exception as e: return "Lỗi mạng: " + str(e)

def get_suggested_friends(session, uid, fb_dtsg, jazoest, lsd, proxies=None):
    url = "https://www.facebook.com/api/graphql/"
    headers = {"content-type": "application/x-www-form-urlencoded", "x-fb-friendly-name": "PeopleYouMayKnowPaginationQuery", "x-fb-lsd": lsd if lsd else "", "origin": "https://www.facebook.com", "referer": "https://www.facebook.com/"}
    variables = {"count": 10, "cursor": None, "scale": 3, "useDefaultActor": False}
    data = {"av": uid, "fb_dtsg": fb_dtsg, "jazoest": jazoest, "lsd": lsd, "__user": uid, "__a": "1", "fb_api_caller_class": "RelayModern", "fb_api_req_friendly_name": "PeopleYouMayKnowPaginationQuery", "variables": json.dumps(variables, separators=(",", ":")), "doc_id": "28614045121363201", "server_timestamps": "true"}
    try:
        res = session.post(url, headers=headers, data=data, timeout=TIMEOUT, proxies=proxies)
        users = []
        for line in res.text.splitlines():
            try: obj = json.loads(line)
            except: continue
            def extract_user(o):
                if isinstance(o, dict):
                    if "user_id" in o or "id" in o:
                        u_id = o.get("user_id") or o.get("id")
                        if isinstance(u_id, str) and u_id.isdigit(): users.append(u_id)
                    for v in o.values(): extract_user(v)
                elif isinstance(o, list):
                    for i in o: extract_user(i)
            extract_user(obj)
        return list(set(users))
    except: return []

@app.route("/api/toggle_setting", methods=["POST"])
def toggle_setting():
    global SHOW_RAW_RESPONSE
    data = request.json
    if "show_raw_response" in data:
        SHOW_RAW_RESPONSE = data["show_raw_response"]
    return jsonify({"success": True, "show_raw_response": SHOW_RAW_RESPONSE})

@app.route("/api/get_settings", methods=["GET"])
def get_settings():
    return jsonify({"show_raw_response": SHOW_RAW_RESPONSE})

@app.route("/api/add_account", methods=["POST"])
def add_account():
    data = request.json
    uid, password, twofa, proxy, datr = data.get("uid"), data.get("pass"), data.get("twofa"), data.get("proxy", ""), data.get("datr", "").strip()
    try:
        fb = facebook_login(uid_phone_mail=uid, password=password, twofactor_code=twofa, proxies=parse_proxy(proxy), datr=datr)
        result = fb.login()
        if result["success"]:
            result["fb_name"] = get_fb_name(result["original_token"]["access_token"], parse_proxy(proxy))
            result["fb_uid"] = result["cookies"]["dict"].get("c_user", "Unknown")
            result["proxy"] = proxy
            result["status"] = "✅ Live"
            result["is_alive"] = True
            result["password"] = password
            return jsonify({"success": True, "data": result})
        return jsonify({"success": False, "error": result["error"]})
    except Exception as e: return jsonify({"success": False, "error": str(e)})

@app.route("/api/check_proxy", methods=["POST"])
def api_check_proxy():
    proxies = parse_proxy(request.json.get("proxy"))
    if not proxies: return jsonify({"success": False, "error": "❌ Proxy rỗng"})
    try:
        r = requests.get("https://api.ipify.org?format=json", proxies=proxies, timeout=10)
        return jsonify({"success": True, "ip": r.json().get("ip")}) if r.status_code == 200 else jsonify({"success": False, "error": "Lỗi kết nối"})
    except: return jsonify({"success": False, "error": "❌ Proxy Die hoặc lỗi kết nối"})

@app.route("/api/get_logs", methods=["POST"])
def api_get_logs(): return jsonify({"logs": bot_logs.get(request.json.get("id"), [])})

@app.route("/api/toggle_bot", methods=["POST"])
def toggle_bot():
    data = request.json
    acc_id, token_data = data.get("id"), data.get("token_data")

    if not token_data: return jsonify({"success": False, "error": "Dữ liệu không hợp lệ."})
    if running_bots.get(acc_id):
        running_bots[acc_id] = False
        if acc_id in bot_logs: bot_logs[acc_id].append(f"[<☆>] Đã dừng nuôi acc.")
        return jsonify({"success": True, "is_running": False})

    running_bots[acc_id] = True
    bot_logs[acc_id] = [f"[<☆>] Bắt đầu nuôi acc..."]

    token_eaaa = token_data["original_token"]["access_token"]
    cookie_dict = token_data["cookies"]["dict"]
    uid = cookie_dict.get("c_user", "0")
    proxies = parse_proxy(token_data.get("proxy", ""))
    user_agent_cua_acc = token_data.get("user_agent", "Dalvik/2.1.0 (Linux; U; Android 9; 23113RKC6C Build/PQ3A.190705.08211809) [FBAN/FB4A;FBAV/417.0.0.33.65;FBPN/com.facebook.katana;FBLC/vi_VN;FBBV/480086274;FBCR/MobiFone;FBMF/Redmi;FBBD/Redmi;FBDV/23113RKC6C;FBSV/9;FBCA/x86:armeabi-v7a;FBDM/{density=1.5,width=1280,height=720};FB_FW/1;FBRV/0;]")

    def add_log(msg, is_error=False, is_success=False, is_warning=False, is_raw=False):
        if acc_id not in bot_logs: bot_logs[acc_id] = []
        if is_error: msg = f"<span style='color:#FF4D4F'>{msg}</span>"
        elif is_success: msg = f"<span style='color:#2DC988'>{msg}</span>"
        elif is_warning: msg = f"<span style='color:#F5A623'>{msg}</span>"
        elif is_raw: msg = f"<span style='color:#829AFF;font-style:italic;'>{msg}</span>"
        
        if is_raw and not SHOW_RAW_RESPONSE:
            return
            
        bot_logs[acc_id].append(msg)
        if len(bot_logs[acc_id]) > 50: bot_logs[acc_id].pop(0)

    def sleep_with_countdown(seconds, message=""):
        m, s = divmod(int(seconds), 60)
        base_msg = message if message else "[<ⴵ>] Đang chờ..."
        add_log(f"{base_msg} (Còn lại: {m:02d}:{s:02d})")
        for i in range(int(seconds) - 1, -1, -1):
            if not running_bots.get(acc_id): break
            time.sleep(1)
            m, s = divmod(i, 60)
            if bot_logs[acc_id]: bot_logs[acc_id][-1] = f"{base_msg} (Còn lại: {m:02d}:{s:02d})"

    def run_bot():
        session = tao_phien(cookie_dict, user_agent_cua_acc, proxies)
        meta = lay_metadata(session, proxies)
        fb_dtsg, lsd = meta.get("fb_dtsg"), meta.get("lsd")

        if not fb_dtsg:
            add_log("[<❌>] Lỗi: Không lấy được fb_dtsg.", is_error=True)
            running_bots[acc_id] = False
            return

        jazoest = "2" + "".join(str(ord(c)) for c in fb_dtsg)
        ai = facebook_ai(MISTRAL_API_KEY)

        session_count = 0
        last_post_session = -96

        while running_bots.get(acc_id):
            try:
                # CHECK LIVE/DIE MỖI ĐẦU PHIÊN
                is_alive = check_live_die(token_eaaa, proxies)
                if not is_alive:
                    add_log("[<❌>] Tài khoản đã bị DIE (Checkpoint/Khóa)! Dừng nuôi acc.", is_error=True)
                    running_bots[acc_id] = False
                    bot_logs[acc_id].append("DIE_ALERT:" + token_data.get("fb_name", "Không rõ tên"))
                    break

                session_count += 1
                can_post = (session_count - last_post_session) >= 96

                if can_post:
                    add_log("[<ⴵ>] Đang đăng bài...")
                    chu_de = random.choice(["tâm trạng", "tình yêu", "cuộc sống", "sự mệt mỏi", "niềm vui", "nỗi buồn", "sự cô đơn", "gia đình", "tình bạn", "ước mơ", "hoài niệm", "sự trưởng thành", "lòng biết ơn", "sự tha thứ", "nỗi nhớ", "sự bình yên", "động lực", "thất bại", "sự thay đổi", "hy vọng", "triết lý sống", "sự chữa lành", "lòng tự trọng", "sự kiên nhẫn", "hạnh phúc giản đơn"])
                    noi_dung = ai.tao_bai_dang(chu_de, proxies)
                    if noi_dung:
                        post_id = graph_dang_bai(noi_dung, token_eaaa, proxies)
                        if post_id and not str(post_id).startswith("ERROR") and not str(post_id).startswith("EXCEPTION"):
                            post_link = f"https://www.facebook.com/{uid}/posts/{post_id.split('_')[-1]}"
                            add_log(f"[<✅>] Đăng bài thành công. Link: {post_link}", is_success=True)
                            last_post_session = session_count
                        else:
                            add_log(f"[<❌>] Đăng bài thất bại! Chi tiết: {post_id}", is_error=True)
                    sleep_with_countdown(random.uniform(120, 180), "[<ⴵ>] Nghỉ ngơi sau khi đăng bài...")

                posts = get_feed_posts(session, uid, fb_dtsg, jazoest, lsd, proxies)

                if isinstance(posts, tuple):
                    real_posts, raw_log = posts
                    add_log(raw_log, is_raw=True)
                    posts = real_posts

                if isinstance(posts, str): 
                    add_log(f"[<❌>] Quét Feed thất bại! {posts}", is_error=True)
                elif posts:
                    so_lan_tuong_tac = random.randint(5, 7)
                    selected_posts = random.sample(posts, min(len(posts), so_lan_tuong_tac))
                    
                    for pid, msg, author_id in selected_posts:
                        if not running_bots.get(acc_id): break
                            
                        full_pid = f"{uid}_{pid}" if "_" not in pid else pid

                        total_wait = random.uniform(10, 15) + random.uniform(2, 4)
                        sleep_with_countdown(total_wait, f"[<ⴵ>] Chuẩn bị tương tác bài: {pid}")

                        reaction, comment, raw_resp = ai.phan_tich_bai_viet(msg, proxies)
                        
                        add_log(f"[AI Raw] {raw_resp}", is_raw=True)

                        res_rx = graph_tha_cam_xuc(full_pid, reaction, token_eaaa, proxies)
                        if res_rx is not True:
                            if "Unsupported post request" in str(res_rx):
                                add_log(f"[<⚠️>] Bỏ qua bài {pid} (Bị chặn quyền tương tác).", is_warning=True)
                            else:
                                add_log(f"[<❌>] Lỗi thả cảm xúc bài {pid}! {res_rx}", is_error=True)
                                add_log(f"[GraphQL Reaction Raw] {res_rx}", is_raw=True)

                        res_cmt = graph_comment(full_pid, comment, token_eaaa, proxies)
                        if res_cmt is not True:
                            if "Unsupported post request" not in str(res_cmt): 
                                add_log(f"[<❌>] Lỗi bình luận bài {pid}! {res_cmt}", is_error=True)
                                add_log(f"[GraphQL Comment Raw] {res_cmt}", is_raw=True)

                        if res_rx is True and res_cmt is True:
                            post_link = format_post_link(pid, uid, author_id)
                            add_log(f"[<✅>] Tương tác thành công. Link: {post_link}", is_success=True)

                        sleep_with_countdown(random.uniform(240, 300), "[<ⴵ>] Nghỉ ngơi giữa các bài viết...")

                if session_count > 2 and (session_count % 8 == 0):
                    add_log("[<ⴵ>] Đang tìm người để kết bạn...")
                    suggested_uids = get_suggested_friends(session, uid, fb_dtsg, jazoest, lsd, proxies)
                    if suggested_uids:
                        targets = random.sample(suggested_uids, min(len(suggested_uids), 2))
                        add_log(f"[<✅>] Đã tìm thấy {len(suggested_uids)} gợi ý. Sẽ kết bạn với {len(targets)} người...", is_success=True)
                        for target_id in targets:
                            if not running_bots.get(acc_id): break
                            sleep_with_countdown(random.uniform(30, 60), "[<ⴵ>] Chuẩn bị gửi lời mời kết bạn...")
                            res_fr = graph_ket_ban(target_id, token_eaaa, proxies)
                            if res_fr is True: add_log(f"[<✅>] Đã gửi lời mời kết bạn tới ID: {target_id}", is_success=True)
                            else: 
                                add_log(f"[<❌>] Gửi lời mời kết bạn thất bại cho ID {target_id}. Chi tiết: {res_fr}", is_error=True)
                                add_log(f"[GraphQL Friend Raw] {res_fr}", is_raw=True)
                    else:
                        add_log("[<❌>] Không lấy được danh sách gợi ý kết bạn.", is_error=True)

                sleep_with_countdown(300, f"[<ⴵ>] Kết thúc phiên {session_count}. Nghỉ ngơi...")

            except Exception as e:
                add_log(f"[<❌>] Lỗi hệ thống nghiêm trọng: {e}", is_error=True)
                sleep_with_countdown(60, "[<ⴵ>] Đang thử phục hồi sau lỗi...")

    threading.Thread(target=run_bot, daemon=True).start()
    return jsonify({"success": True, "message": "Đã bắt đầu Bot", "is_running": True})

@app.route("/")
def index():
    paths = ["index.html", "assets/index.html", os.path.join(os.path.dirname(__file__), "index.html")]
    for p in paths:
        if os.path.exists(p): return send_from_directory(os.path.dirname(p) if os.path.dirname(p) else ".", os.path.basename(p))
    return "[<❌>] Lỗi: Không tìm thấy giao diện!", 404

def run_server():
    def run(): app.run(host="127.0.0.1", port=8080, threaded=True, use_reloader=False, debug=False)
    t = threading.Thread(target=run); t.daemon = True; t.start()

if __name__ == "__main__":
    run_server()
    while True: time.sleep(1)