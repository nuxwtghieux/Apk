package com.snow.panel;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // 1. Khởi động Python
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        
        // 2. Chạy file app.py trong thư mục python (ngầm)
        Python.getInstance().getModule("app").callAttr("run_server");

        // 3. Mở giao diện Web
        setContentView(R.layout.activity_main);
        WebView myWebView = findViewById(R.id.webview);
        myWebView.getSettings().setJavaScriptEnabled(true);
        
        // Đợi 2 giây để server Python khởi động xong rồi mới load web
        new android.os.Handler().postDelayed(() -> {
            myWebView.loadUrl("http://127.0.0.1:8080");
        }, 2000);
    }
}